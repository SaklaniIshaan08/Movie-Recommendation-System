import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { CURATED_TRAILER_KEYS, isValidYouTubeKey } from './src/data/trailers.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const ALLOWED_INDUSTRIES = new Set(['Hindi', 'Malayalam', 'Tamil', 'Telugu', 'Kannada']);
const LANG_ISO_MAP: Record<string, string> = {
  Hindi: 'hi',
  Malayalam: 'ml',
  Tamil: 'ta',
  Telugu: 'te',
  Kannada: 'kn',
};

interface TrailerCacheEntry {
  youtubeKey: string | null;
  backdropUrl: string | null;
  startSec: number;
  endSec: number;
  source: 'tmdb' | 'youtube' | 'curated' | 'none';
}

const trailerCache = new Map<string, TrailerCacheEntry>();
const MAX_CACHE_ENTRIES = 2000;

function setCache(key: string, value: TrailerCacheEntry): void {
  if (trailerCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = trailerCache.keys().next().value;
    if (oldestKey) trailerCache.delete(oldestKey);
  }
  trailerCache.set(key, value);
}

function parseDurationSeconds(simpleText: string | undefined): number | null {
  if (!simpleText) return null;
  const parts = simpleText
    .trim()
    .split(':')
    .map((p) => Number.parseInt(p, 10));
  if (parts.some((n) => !Number.isFinite(n) || n < 0)) return null;
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return null;
}

function computeClipWindow(durationSeconds: number | null): { startSec: number; endSec: number } {
  if (!durationSeconds || durationSeconds <= 0) {
    return { startSec: 8, endSec: 50 };
  }
  if (durationSeconds <= 48) {
    const startSec = Math.min(3, Math.floor(durationSeconds * 0.1));
    const endSec = Math.max(startSec + 12, durationSeconds - 3);
    return { startSec, endSec };
  }
  const startSec = 10;
  const endSec = Math.min(54, durationSeconds - 4);
  return { startSec, endSec: Math.max(startSec + 18, endSec) };
}

async function fetchTmdbMedia(
  title: string,
  year: number | null,
  lang: string | null
): Promise<{ youtubeKey: string | null; backdropUrl: string | null } | null> {
  const apiKey = process.env.TMDB_API_KEY?.trim();
  if (!apiKey) return null;

  const searchParams = new URLSearchParams({
    api_key: apiKey,
    query: title,
    include_adult: 'false',
  });
  if (year !== null) {
    searchParams.set('year', String(year));
  }

  const searchRes = await fetch(
    `https://api.themoviedb.org/3/search/movie?${searchParams.toString()}`,
    { signal: AbortSignal.timeout(4000) }
  );
  if (!searchRes.ok) return null;

  const searchJson = (await searchRes.json()) as {
    results?: Array<{
      id?: number;
      original_language?: string;
      release_date?: string;
      backdrop_path?: string | null;
    }>;
  };

  const results = searchJson.results ?? [];
  if (results.length === 0) return null;

  const targetIso = lang ? LANG_ISO_MAP[lang] : undefined;
  const bestMatch =
    results.find(
      (r) =>
        typeof r.id === 'number' &&
        targetIso &&
        r.original_language === targetIso &&
        (!year || (r.release_date ?? '').startsWith(String(year)))
    ) ||
    results.find((r) => typeof r.id === 'number' && targetIso && r.original_language === targetIso) ||
    results[0];

  if (!bestMatch || typeof bestMatch.id !== 'number') return null;

  const detailParams = new URLSearchParams({
    api_key: apiKey,
    append_to_response: 'videos',
  });

  const detailRes = await fetch(
    `https://api.themoviedb.org/3/movie/${bestMatch.id}?${detailParams.toString()}`,
    { signal: AbortSignal.timeout(4000) }
  );

  let rawBackdrop = bestMatch.backdrop_path ?? null;
  let youtubeKey: string | null = null;

  if (detailRes.ok) {
    const detailJson = (await detailRes.json()) as {
      backdrop_path?: string | null;
      videos?: {
        results?: Array<{
          site?: string;
          type?: string;
          key?: string;
          official?: boolean;
        }>;
      };
    };

    if (detailJson.backdrop_path) {
      rawBackdrop = detailJson.backdrop_path;
    }

    const videos = (detailJson.videos?.results ?? []).filter(
      (v) => v.site === 'YouTube' && isValidYouTubeKey(v.key)
    );

    const prioritized =
      videos.find((v) => v.official && (v.type === 'Teaser' || v.type === 'Trailer')) ||
      videos.find((v) => v.type === 'Trailer' || v.type === 'Teaser') ||
      videos[0];

    if (prioritized && isValidYouTubeKey(prioritized.key)) {
      youtubeKey = prioritized.key;
    }
  }

  const backdropUrl =
    rawBackdrop && /^\/[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/i.test(rawBackdrop)
      ? `https://image.tmdb.org/t/p/w1280${rawBackdrop}`
      : null;

  return { youtubeKey, backdropUrl };
}

function isFullLengthUpload(videoTitle: string, durationSeconds: number | null): boolean {
  if (durationSeconds !== null && durationSeconds > 600) return true;
  const v = videoTitle.toLowerCase();
  return /\bfull\s*(hindi|malayalam|tamil|telugu|kannada|indian|hd)?\s*(movie|film|comedy\s*movie|drama\s*movie)\b/.test(
    v
  ) || /\bfull\s+jukebox\b/.test(v);
}

function scoreCandidate(
  videoTitle: string,
  durationSeconds: number | null,
  movieTitle: string,
  year: number | null
): number {
  const v = videoTitle.toLowerCase();
  const words = movieTitle
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 2);

  let score = 0;
  for (const w of words) {
    if (v.includes(w)) score += 4;
  }
  if (v.includes('official')) score += 4;
  if (v.includes('teaser') || v.includes('trailer') || v.includes('prevue') || v.includes('promo')) {
    score += 6;
  } else if (v.includes('scene') || v.includes('clip') || v.includes('glimpse')) {
    score += 2;
  }
  if (year && v.includes(String(year))) score += 2;

  // Duration preference: 25s to 5m ideal trailer/teaser window; reject full movies
  if (durationSeconds !== null) {
    if (durationSeconds >= 25 && durationSeconds <= 320) score += 12;
    else if (durationSeconds > 320 && durationSeconds <= 600) score += 4;
    else if (durationSeconds > 600) score -= 40;
  }

  if (isFullLengthUpload(videoTitle, durationSeconds)) {
    score -= 40;
  }

  if (
    v.includes('reaction') ||
    v.includes('explained') ||
    v.includes('roast') ||
    v.includes('spoof') ||
    v.includes('fan made') ||
    v.includes('concept') ||
    v.includes('review') ||
    v.includes('lyrical')
  ) {
    score -= 10;
  }

  return score;
}

interface ParsedSearchCandidate {
  id: string;
  title: string;
  durationSeconds: number | null;
}

function extractCandidatesFromHtml(html: string): ParsedSearchCandidate[] {
  const match = html.match(/var ytInitialData = (\{.*?\});<\/script>/);
  if (match) {
    try {
      const json = JSON.parse(match[1]) as {
        contents?: {
          twoColumnSearchResultsRenderer?: {
            primaryContents?: {
              sectionListRenderer?: {
                contents?: Array<{
                  itemSectionRenderer?: {
                    contents?: Array<{
                      videoRenderer?: {
                        videoId?: string;
                        title?: { runs?: Array<{ text?: string }> };
                        lengthText?: { simpleText?: string };
                      };
                    }>;
                  };
                }>;
              };
            };
          };
        };
      };

      const sections =
        json.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer
          ?.contents ?? [];
      const out: ParsedSearchCandidate[] = [];
      const seen = new Set<string>();

      for (const sec of sections) {
        for (const item of sec.itemSectionRenderer?.contents ?? []) {
          const vr = item.videoRenderer;
          if (!vr?.videoId || !isValidYouTubeKey(vr.videoId) || seen.has(vr.videoId)) continue;
          seen.add(vr.videoId);
          out.push({
            id: vr.videoId,
            title: vr.title?.runs?.map((r) => r.text ?? '').join('') ?? '',
            durationSeconds: parseDurationSeconds(vr.lengthText?.simpleText),
          });
        }
      }

      if (out.length > 0) return out;
    } catch {
      // Fall through to regex IDs if JSON format changes
    }
  }

  const rawIds = [...html.matchAll(/"videoId":"([a-zA-Z0-9_-]{11})"/g)].map((m) => m[1]);
  return Array.from(new Set(rawIds))
    .filter(isValidYouTubeKey)
    .slice(0, 8)
    .map((id) => ({ id, title: '', durationSeconds: null }));
}

async function resolveYouTubeTrailer(
  title: string,
  year: number | null,
  lang: string | null
): Promise<{ youtubeKey: string; startSec: number; endSec: number } | null> {
  const yearPart = year ? `${year}` : '';
  const langPart = lang ?? 'Indian';
  const queries = [
    `${title} ${yearPart} ${langPart} official trailer`.trim(),
    `${title} ${yearPart} official teaser promo`.trim(),
    `${title} ${yearPart} short scene clip`.trim(),
  ];

  for (const q of queries) {
    try {
      const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;
      const res = await fetch(searchUrl, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9',
        },
        signal: AbortSignal.timeout(4500),
      });
      if (!res.ok) continue;

      const html = await res.text();
      const parsed = extractCandidatesFromHtml(html)
        .filter((c) => !isFullLengthUpload(c.title, c.durationSeconds))
        .slice(0, 8);
      if (parsed.length === 0) continue;

      const checks = await Promise.allSettled(
        parsed.map(async (cand) => {
          const oeUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(
            `https://www.youtube.com/watch?v=${cand.id}`
          )}&format=json`;
          const oe = await fetch(oeUrl, { signal: AbortSignal.timeout(3000) });
          if (!oe.ok) return null;
          const info = (await oe.json()) as { title?: string };
          const verifiedTitle = typeof info.title === 'string' ? info.title : cand.title;
          if (isFullLengthUpload(verifiedTitle, cand.durationSeconds)) return null;
          return {
            id: cand.id,
            durationSeconds: cand.durationSeconds,
            score: scoreCandidate(verifiedTitle, cand.durationSeconds, title, year),
          };
        })
      );

      const valid = checks
        .map((c) => (c.status === 'fulfilled' ? c.value : null))
        .filter((x): x is { id: string; durationSeconds: number | null; score: number } => Boolean(x))
        .sort((a, b) => b.score - a.score);

      if (valid.length > 0 && valid[0].score > 0) {
        const win = computeClipWindow(valid[0].durationSeconds);
        return { youtubeKey: valid[0].id, ...win };
      }
    } catch {
      // Try next fallback query
    }
  }

  return null;
}

async function startServer() {
  const app = express();
  app.disable('x-powered-by');

  app.get('/api/trailer', async (req, res) => {
    const rawTitle = typeof req.query.title === 'string' ? req.query.title.trim() : '';
    if (!rawTitle || rawTitle.length > 140) {
      res.status(400).json({ error: 'Valid film title is required.' });
      return;
    }

    const rawYear = typeof req.query.year === 'string' ? Number.parseInt(req.query.year, 10) : NaN;
    const year = Number.isInteger(rawYear) && rawYear >= 1940 && rawYear <= 2030 ? rawYear : null;

    const rawLang = typeof req.query.lang === 'string' ? req.query.lang.trim() : '';
    const lang = ALLOWED_INDUSTRIES.has(rawLang) ? rawLang : null;

    const normalizedTitle = rawTitle.toLowerCase();
    const cacheKey = `${normalizedTitle}::${year ?? ''}::${lang ?? ''}`;

    const cached = trailerCache.get(cacheKey);
    if (cached) {
      res.json(cached);
      return;
    }

    const curatedKey = CURATED_TRAILER_KEYS[normalizedTitle] ?? null;

    try {
      const tmdbResult = await fetchTmdbMedia(rawTitle, year, lang).catch(() => null);
      let youtubeKey: string | null = tmdbResult?.youtubeKey ?? curatedKey;
      let startSec = 10;
      let endSec = 52;
      let source: TrailerCacheEntry['source'] = tmdbResult?.youtubeKey
        ? 'tmdb'
        : curatedKey
        ? 'curated'
        : 'none';

      if (!youtubeKey) {
        const resolved = await resolveYouTubeTrailer(rawTitle, year, lang);
        if (resolved) {
          youtubeKey = resolved.youtubeKey;
          startSec = resolved.startSec;
          endSec = resolved.endSec;
          source = 'youtube';
        }
      }

      const finalEntry: TrailerCacheEntry = {
        youtubeKey,
        backdropUrl: tmdbResult?.backdropUrl ?? null,
        startSec,
        endSec,
        source: youtubeKey ? source : tmdbResult?.backdropUrl ? 'tmdb' : 'none',
      };
      setCache(cacheKey, finalEntry);
      res.json(finalEntry);
    } catch {
      const fallbackEntry: TrailerCacheEntry = {
        youtubeKey: curatedKey,
        backdropUrl: null,
        startSec: 10,
        endSec: 52,
        source: curatedKey ? 'curated' : 'none',
      };
      setCache(cacheKey, fallbackEntry);
      res.json(fallbackEntry);
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CineIndia server listening on http://localhost:${PORT}`);
  });
}

startServer();
