import type {
  AlgoWeights,
  Industry,
  Movie,
  SimilarityMatch,
  TasteDnaProfile,
} from '../types/movie';
import { computeStoryCosine, getTfIdfIndex } from './recommender';

export interface TasteDnaRecommendOptions {
  crossIndustryOnly?: boolean;
  languageFilter?: Industry | 'ALL';
  excludedGenres?: string[];
  limit?: number;
}

export function buildTasteDnaProfile(
  seedIds: number[],
  seedWeightsMap: Record<number, number>,
  allMovies: Movie[]
): TasteDnaProfile | null {
  const weightedSeeds = seedIds
    .map((id) => {
      const movie = allMovies.find((m) => m.id === id);
      if (!movie) return null;
      return {
        movie,
        weight: seedWeightsMap[id] ?? 1,
      };
    })
    .filter((x): x is { movie: Movie; weight: number } => Boolean(x));

  if (weightedSeeds.length === 0) return null;

  const totalWeight = weightedSeeds.reduce((sum, s) => sum + s.weight, 0) || 1;
  const tfidf = getTfIdfIndex(allMovies);

  // 1. Genre & Language weighted accumulators
  const genreWeights = new Map<string, { weight: number; count: number }>();
  const langWeights = new Map<Industry, { weight: number; count: number }>();
  const centroidStoryVec = new Map<string, number>();

  let yearWeightedSum = 0;
  let runtimeWeightedSum = 0;
  let minYear = Infinity;
  let maxYear = -Infinity;

  const seedSummaries = weightedSeeds.map(({ movie, weight }) => {
    const share = weight / totalWeight;
    yearWeightedSum += movie.year * share;
    runtimeWeightedSum += movie.runtime * share;
    if (movie.year < minYear) minYear = movie.year;
    if (movie.year > maxYear) maxYear = movie.year;

    const lPrev = langWeights.get(movie.lang) ?? { weight: 0, count: 0 };
    langWeights.set(movie.lang, { weight: lPrev.weight + share, count: lPrev.count + 1 });

    const perGenreShare = share / Math.max(1, movie.genres.length);
    for (const g of movie.genres) {
      const gPrev = genreWeights.get(g) ?? { weight: 0, count: 0 };
      genreWeights.set(g, { weight: gPrev.weight + perGenreShare, count: gPrev.count + 1 });
    }

    const vec = tfidf.vectors.get(movie.id) ?? new Map<string, number>();
    const topTerms = Array.from(vec.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([t]) => t);

    for (const [term, val] of vec.entries()) {
      centroidStoryVec.set(term, (centroidStoryVec.get(term) ?? 0) + val * share);
    }

    return {
      movie,
      weight,
      contributionPct: Math.round(share * 100),
      topGenres: movie.genres.slice(0, 3),
      topThemes: topTerms,
    };
  });

  const genreDistribution = Array.from(genreWeights.entries())
    .map(([genre, { weight, count }]) => ({
      genre,
      pct: Math.round(weight * 100),
      count,
    }))
    .sort((a, b) => b.pct - a.pct);

  const languageDistribution = Array.from(langWeights.entries())
    .map(([lang, { weight, count }]) => ({
      lang,
      pct: Math.round(weight * 100),
      count,
    }))
    .sort((a, b) => b.pct - a.pct);

  const storyThemes = Array.from(centroidStoryVec.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([term, score]) => ({
      term,
      score: Math.round(score * 100),
    }));

  const weightedMeanYear = Math.round(yearWeightedSum);
  let dominantEra = '2020s & Modern';
  if (weightedMeanYear < 1980) dominantEra = '1950s–1970s Golden Age';
  else if (weightedMeanYear < 1990) dominantEra = '1980s New Wave';
  else if (weightedMeanYear < 2000) dominantEra = '1990s Turning Point';
  else if (weightedMeanYear < 2010) dominantEra = '2000s Transition';
  else if (weightedMeanYear < 2020) dominantEra = '2010s Modern Wave';

  const weightedAvgMinutes = Math.round(runtimeWeightedSum);
  const pacingLabel =
    weightedAvgMinutes < 120
      ? 'Tight (<120m)'
      : weightedAvgMinutes <= 150
      ? 'Standard (120–150m)'
      : 'Epic (>150m)';

  return {
    seeds: seedSummaries,
    genreDistribution,
    languageDistribution,
    storyThemes,
    eraProfile: {
      weightedMeanYear,
      minYear,
      maxYear,
      dominantEra,
    },
    runtimeProfile: {
      weightedAvgMinutes,
      pacingLabel,
    },
  };
}

export function recommendFromTasteDna(
  profile: TasteDnaProfile,
  allMovies: Movie[],
  weights: AlgoWeights,
  options: TasteDnaRecommendOptions = {}
): SimilarityMatch[] {
  const {
    crossIndustryOnly = false,
    languageFilter = 'ALL',
    excludedGenres = [],
    limit = 4,
  } = options;
  if (profile.seeds.length < 3) return [];

  const seedSet = new Set(profile.seeds.map((s) => s.movie.id));
  const seedLangs = new Set(profile.seeds.map((s) => s.movie.lang));
  const seedDirectors = new Set(profile.seeds.map((s) => s.movie.director));
  const seedCast = new Set(profile.seeds.flatMap((s) => s.movie.cast));
  const excludedSet = new Set(excludedGenres);

  // Build normalized genre preference vector (excluding muted genres)
  const activeGenres = profile.genreDistribution.filter(
    (g) => !excludedSet.has(g.genre)
  );
  const genreTotalPct = activeGenres.reduce((s, g) => s + g.pct, 0) || 1;
  const genreWeightMap = new Map<string, number>(
    activeGenres.map((g) => [g.genre, g.pct / genreTotalPct])
  );

  // Build normalized L2 centroid story vector from weighted seeds
  const tfidf = getTfIdfIndex(allMovies);
  const centroid = new Map<string, number>();
  const totalSeedWeight = profile.seeds.reduce((s, x) => s + x.weight, 0) || 1;

  for (const s of profile.seeds) {
    const share = s.weight / totalSeedWeight;
    const vec = tfidf.vectors.get(s.movie.id) ?? new Map();
    for (const [term, val] of vec.entries()) {
      centroid.set(term, (centroid.get(term) ?? 0) + val * share);
    }
  }
  let normSq = 0;
  for (const val of centroid.values()) normSq += val * val;
  const norm = Math.sqrt(normSq) || 1;
  for (const [term, val] of centroid.entries()) {
    centroid.set(term, val / norm);
  }

  const totalAlgoWeight = Math.max(
    1,
    weights.genre + weights.director + weights.cast + weights.story + weights.cross + weights.era
  );
  const metaWeightSum = weights.genre + weights.director + weights.cast;

  const matches: SimilarityMatch[] = [];

  for (const cand of allMovies) {
    if (seedSet.has(cand.id)) continue;
    if (languageFilter !== 'ALL' && cand.lang !== languageFilter) continue;
    if (languageFilter === 'ALL' && crossIndustryOnly && seedLangs.has(cand.lang)) continue;

    // Genre overlap with weighted Taste DNA vector
    const matchedGenres = cand.genres.filter((g) => genreWeightMap.has(g));
    const genreMatchSum = matchedGenres.reduce(
      (s, g) => s + (genreWeightMap.get(g) ?? 0),
      0
    );
    const genreScore = Math.min(1, genreMatchSum * 1.6);

    const sameDirector = seedDirectors.has(cand.director);
    const sharedCast = cand.cast.filter((c) => seedCast.has(c));
    const castScore = Math.min(1, sharedCast.length / 2);

    const metadataPct = Math.round(
      ((genreScore * weights.genre +
        (sameDirector ? 1 : 0) * weights.director +
        castScore * weights.cast) /
        Math.max(1, metaWeightSum)) *
        100
    );

    const candVec = tfidf.vectors.get(cand.id) ?? new Map();
    const { cosine, sharedTerms } = computeStoryCosine(centroid, candVec);
    const storyPct = Math.round(cosine * 100);

    const bridgePct = !seedLangs.has(cand.lang) ? 100 : 0;
    const eraPct = Math.max(
      0,
      Math.round(100 - Math.abs(profile.eraProfile.weightedMeanYear - cand.year) * 3.5)
    );

    const metadataContribution = Math.round((metadataPct * metaWeightSum) / totalAlgoWeight);
    const storyContribution = Math.round((storyPct * weights.story) / totalAlgoWeight);
    const bridgeContribution = Math.round((bridgePct * weights.cross) / totalAlgoWeight);
    const eraContribution = Math.round((eraPct * weights.era) / totalAlgoWeight);

    const score = Math.min(
      100,
      metadataContribution + storyContribution + bridgeContribution + eraContribution
    );

    const reasons: string[] = [];
    if (matchedGenres.length > 0) {
      reasons.push(`Profile genres: ${matchedGenres.join(', ')}`);
    }
    if (sharedTerms.length > 0) {
      reasons.push(`Story motifs: ${sharedTerms.slice(0, 3).join(', ')}`);
    }
    if (sameDirector) reasons.push(`Seed filmmaker: ${cand.director}`);
    if (!seedLangs.has(cand.lang)) reasons.push(`New industry discovery: ${cand.lang}`);

    matches.push({
      movie: cand,
      score,
      breakdown: {
        metadataPct,
        storyPct,
        bridgePct,
        eraPct,
        metadataContribution,
        storyContribution,
        bridgeContribution,
        eraContribution,
      },
      sharedGenres: matchedGenres,
      sharedCast,
      sameDirector,
      sharedStoryTerms: sharedTerms,
      reasons: reasons.length ? reasons : [`Era match (${cand.year}) · ★ ${cand.rating.toFixed(1)}`],
    });
  }

  matches.sort((a, b) => b.score - a.score || b.movie.rating - a.movie.rating);
  return matches.slice(0, limit);
}
