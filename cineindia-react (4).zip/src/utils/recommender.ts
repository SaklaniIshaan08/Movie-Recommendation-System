import type {
  AlgoWeights,
  HiddenGemMetrics,
  Industry,
  Movie,
  ParsedQuery,
  SimilarityMatch,
} from '../types/movie';

export const INDUSTRIES: Industry[] = [
  'Hindi',
  'Malayalam',
  'Tamil',
  'Telugu',
  'Kannada',
];

export const DEFAULT_ALGO_WEIGHTS: AlgoWeights = {
  genre: 25,
  director: 20,
  cast: 10,
  story: 25,
  cross: 10,
  era: 10,
};

export const SCRIPT_SYNONYMS: Record<string, string> = {
  'பொன்னியின்': 'ponniyin',
  'மகாராஜா': 'maharaja',
  'கைதி': 'kaithi',
  'விக்ரம்': 'vikram',
  'ദൃശ്യം': 'drishyam',
  'കുമ്പളങ്ങി': 'kumbalangi',
  'ഭ്രമയുഗം': 'bramayugam',
  'आवेशम': 'aavesham',
  'तुम्बाड': 'tumbbad',
  'शोले': 'sholay',
  'धुरंधर': 'dhurandhar',
  'जवान': 'jawan',
  'ಕಾಂತಾರ': 'kantara',
  'సలార్': 'salaar',
  'సరిపోదా': 'saripodhaa',
  'சிறந்த': 'tamil',
  durando: 'dhurandhar',
  durandhar: 'dhurandhar',
  gabbar: 'sholay',
  hastar: 'tumbbad',
  ranganna: 'aavesham',
  baburao: 'hera pheri',
  rancho: '3 idiots',
  kattappa: 'baahubali',
  rocky: 'k.g.f',
  kgf: 'k.g.f',
  ddlj: 'dilwale dulhania',
  znmd: 'zindagi na milegi',
};

const INDUSTRY_LOWER = ['hindi', 'malayalam', 'tamil', 'telugu', 'kannada'] as const;

const STORY_STOP_WORDS = new Set([
  'the', 'and', 'for', 'with', 'that', 'this', 'from', 'into', 'when', 'where',
  'which', 'while', 'after', 'before', 'their', 'they', 'them', 'there', 'have',
  'has', 'had', 'his', 'her', 'she', 'him', 'who', 'whom', 'whose', 'about',
  'between', 'through', 'against', 'under', 'over', 'amid', 'amidst', 'across',
  'young', 'man', 'woman', 'two', 'three', 'one', 'life', 'story', 'film',
  'turns', 'finds', 'must', 'sets', 'takes', 'becomes', 'years', 'time',
  'forced', 'discovers', 'leads', 'lives', 'journey', 'world', 'story', 'hindi',
  'tamil', 'telugu', 'malayalam', 'kannada', 'indian', 'india',
]);

export function tokenizeStoryText(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 3 && !STORY_STOP_WORDS.has(t));
}

export interface TfIdfIndex {
  idf: Map<string, number>;
  vectors: Map<number, Map<string, number>>;
}

let cachedTfIdfIndex: TfIdfIndex | null = null;
let cachedIndexCount = -1;

export function getTfIdfIndex(movies: Movie[]): TfIdfIndex {
  if (cachedTfIdfIndex && cachedIndexCount === movies.length) {
    return cachedTfIdfIndex;
  }

  const df = new Map<string, number>();
  const docTokens = new Map<number, string[]>();

  for (const m of movies) {
    const tokens = tokenizeStoryText(m.synopsis);
    docTokens.set(m.id, tokens);
    const unique = new Set(tokens);
    for (const term of unique) {
      df.set(term, (df.get(term) ?? 0) + 1);
    }
  }

  const N = Math.max(1, movies.length);
  const idf = new Map<string, number>();
  for (const [term, freq] of df.entries()) {
    idf.set(term, Math.log((N + 1) / (freq + 1)) + 1);
  }

  const vectors = new Map<number, Map<string, number>>();
  for (const m of movies) {
    const tokens = docTokens.get(m.id) ?? [];
    const tf = new Map<string, number>();
    for (const t of tokens) {
      tf.set(t, (tf.get(t) ?? 0) + 1);
    }

    const vec = new Map<string, number>();
    let normSq = 0;
    for (const [term, count] of tf.entries()) {
      const weight = (1 + Math.log(count)) * (idf.get(term) ?? 1);
      vec.set(term, weight);
      normSq += weight * weight;
    }

    const norm = Math.sqrt(normSq) || 1;
    for (const [term, val] of vec.entries()) {
      vec.set(term, val / norm);
    }
    vectors.set(m.id, vec);
  }

  cachedTfIdfIndex = { idf, vectors };
  cachedIndexCount = movies.length;
  return cachedTfIdfIndex;
}

export function computeStoryCosine(
  vecA: Map<string, number>,
  vecB: Map<string, number>
): { cosine: number; sharedTerms: string[] } {
  let dot = 0;
  const termProducts: Array<{ term: string; product: number }> = [];

  for (const [term, valA] of vecA.entries()) {
    const valB = vecB.get(term);
    if (valB !== undefined) {
      const prod = valA * valB;
      dot += prod;
      termProducts.push({ term, product: prod });
    }
  }

  termProducts.sort((a, b) => b.product - a.product);
  return {
    cosine: Math.min(1, Math.max(0, dot)),
    sharedTerms: termProducts.slice(0, 4).map((x) => x.term),
  };
}

export function parseNaturalLanguageQuery(raw: string): ParsedQuery | null {
  const q = raw.trim().toLowerCase();
  if (!q) return null;

  const parsed: ParsedQuery = {
    lang: null,
    genres: [],
    maxRuntime: null,
    minYear: null,
    maxYear: null,
    keywords: [],
    mappedFromScript: null,
  };

  for (const [key, mapped] of Object.entries(SCRIPT_SYNONYMS)) {
    if (q.includes(key)) {
      parsed.mappedFromScript = `${key} → "${mapped}"`;
      parsed.keywords.push(mapped);
    }
  }

  for (const l of INDUSTRY_LOWER) {
    if (new RegExp(`\\b${l}\\b`, 'i').test(q)) {
      parsed.lang = (l.charAt(0).toUpperCase() + l.slice(1)) as Industry;
    }
  }

  const hrMatch = q.match(/(?:under|below|<|less than)\s*(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hour|hours)\b/);
  if (hrMatch) {
    parsed.maxRuntime = Math.round(parseFloat(hrMatch[1]) * 60);
  }

  const minMatch = q.match(/(?:under|below|<|less than)\s*(\d+)\s*(?:m|min|mins|minutes)\b/);
  if (minMatch) {
    parsed.maxRuntime = parseInt(minMatch[1], 10);
  }

  const decadeMatch = q.match(/\b(19[4-9]0|20[0-2]0)s\b/);
  if (decadeMatch) {
    const start = parseInt(decadeMatch[1], 10);
    parsed.minYear = start;
    parsed.maxYear = start + 9;
  } else {
    const shortDecade = q.match(/\b([5-9]0)s\b/);
    if (shortDecade) {
      const start = 1900 + parseInt(shortDecade[1], 10);
      parsed.minYear = start;
      parsed.maxYear = start + 9;
    }
  }

  const stopWords = new Set([
    'under', 'below', 'less', 'than', 'hours', 'hour', 'hrs', 'hr',
    'mins', 'min', 'minutes', 'movies', 'films', 'movie', 'film',
    'with', 'and', 'the', 'from', 'in',
  ]);

  const tokens = q
    .replace(/[^\w\s\u0900-\u0DFF.-]/g, ' ')
    .split(/\s+/)
    .filter((t) => {
      if (t.length <= 1) return false;
      if (stopWords.has(t)) return false;
      if ((INDUSTRY_LOWER as readonly string[]).includes(t)) return false;
      if (decadeMatch && t === `${decadeMatch[1]}s`) return false;
      if (hrMatch && hrMatch[0].includes(t)) return false;
      if (minMatch && minMatch[0].includes(t)) return false;
      return true;
    });

  for (const token of tokens) {
    if (SCRIPT_SYNONYMS[token]) {
      parsed.mappedFromScript = `${token} → "${SCRIPT_SYNONYMS[token]}"`;
      parsed.keywords.push(SCRIPT_SYNONYMS[token]);
    } else if (!parsed.keywords.includes(token)) {
      parsed.keywords.push(token);
    }
  }

  return parsed;
}

// =====================================================================
// Bayesian Weighted Rating + Cohort Under-Discovery Signal (Hidden Gems)
// =====================================================================

interface CohortStats {
  meanRating: number;
  priorVotes: number;
  sortedVotes: number[];
}

let cachedGemMap: Map<number, HiddenGemMetrics> | null = null;
let cachedGemCount = -1;

export function buildHiddenGemMetricsMap(movies: Movie[]): Map<number, HiddenGemMetrics> {
  if (cachedGemMap && cachedGemCount === movies.length) {
    return cachedGemMap;
  }

  const cohorts = new Map<Industry, CohortStats>();

  for (const lang of INDUSTRIES) {
    const subset = movies.filter((m) => m.lang === lang);
    const meanRating =
      subset.reduce((sum, m) => sum + m.rating, 0) / Math.max(1, subset.length);
    const sortedVotes = subset.map((m) => m.votes).sort((a, b) => a - b);
    const p35 = sortedVotes[Math.floor(sortedVotes.length * 0.35)] ?? 5000;
    const priorVotes = Math.max(2500, p35);
    cohorts.set(lang, { meanRating, priorVotes, sortedVotes });
  }

  const metricsMap = new Map<number, HiddenGemMetrics>();

  for (const m of movies) {
    const cohort = cohorts.get(m.lang)!;
    const v = m.votes;
    const R = m.rating;
    const C = cohort.meanRating;
    const prior = cohort.priorVotes;

    // Standard IMDb Bayesian weighted rating inside language cohort
    const bayesianRating = Number(((v / (v + prior)) * R + (prior / (v + prior)) * C).toFixed(2));

    // Visibility percentile inside language cohort (0 = lowest votes, 1 = highest votes)
    const lessOrEqual = cohort.sortedVotes.filter((val) => val <= v).length;
    const cohortVisibilityPct = lessOrEqual / Math.max(1, cohort.sortedVotes.length);
    const underDiscoveryPct = Math.round((1 - cohortVisibilityPct) * 100);

    // True Hidden Gem: high reference rating (>= 7.8), exceeds cohort Bayesian floor,
    // and sits in the bottom 35% of reference visibility in its industry.
    const qualifies = R >= 7.8 && bayesianRating >= C && cohortVisibilityPct <= 0.35;

    const gemScore = Number((bayesianRating * 10 + (1 - cohortVisibilityPct) * 18).toFixed(2));

    metricsMap.set(m.id, {
      qualifies,
      bayesianRating,
      cohortMeanRating: Number(C.toFixed(2)),
      cohortPriorVotes: prior,
      cohortVisibilityPct: Number(cohortVisibilityPct.toFixed(2)),
      underDiscoveryPct,
      gemScore,
    });
  }

  cachedGemMap = metricsMap;
  cachedGemCount = movies.length;
  return metricsMap;
}

export function getHiddenGemMetrics(movie: Movie, allMovies: Movie[]): HiddenGemMetrics {
  return buildHiddenGemMetricsMap(allMovies).get(movie.id)!;
}

export function isHiddenGem(movie: Movie, allMovies?: Movie[]): boolean {
  if (allMovies) {
    return getHiddenGemMetrics(movie, allMovies).qualifies;
  }
  return movie.rating >= 7.8 && movie.votes < 9000;
}

export function computeGemScore(movie: Movie, allMovies?: Movie[]): number {
  if (allMovies) {
    return getHiddenGemMetrics(movie, allMovies).gemScore;
  }
  return (movie.rating * 12) / Math.log10(movie.votes + 10);
}

// =====================================================================
// Explainable Decomposed Similarity (Metadata + Story Cosine + Bridge + Era)
// =====================================================================

export function computeSimilarity(
  source: Movie,
  candidate: Movie,
  weights: AlgoWeights,
  allMovies: Movie[],
  crossIndustryOnly = true
): SimilarityMatch | null {
  if (source.id === candidate.id) return null;
  if (crossIndustryOnly && source.lang === candidate.lang) return null;

  const sharedGenres = source.genres.filter((g) => candidate.genres.includes(g));
  const unionGenreCount = new Set([...source.genres, ...candidate.genres]).size || 1;
  const genreJaccard = sharedGenres.length / unionGenreCount;

  const sameDirector = source.director === candidate.director;
  const sharedCast = source.cast.filter((c) => candidate.cast.includes(c));
  const maxSharedCast = Math.max(1, Math.min(source.cast.length, candidate.cast.length));
  const castRatio = sharedCast.length / maxSharedCast;

  // Weighted metadata overlap score (0..100)
  const metaWeightSum = Math.max(1, weights.genre + weights.director + weights.cast);
  const metadataPct = Math.round(
    ((genreJaccard * weights.genre +
      (sameDirector ? 1 : 0) * weights.director +
      castRatio * weights.cast) /
      metaWeightSum) *
      100
  );

  // Pure TF-IDF plot/synopsis cosine similarity (0..100)
  const tfidf = getTfIdfIndex(allMovies);
  const vecA = tfidf.vectors.get(source.id) ?? new Map();
  const vecB = tfidf.vectors.get(candidate.id) ?? new Map();
  const { cosine, sharedTerms } = computeStoryCosine(vecA, vecB);
  const storyPct = Math.round(cosine * 100);

  // Cross-industry bridge & era proximity (0..100)
  const bridgePct = source.lang !== candidate.lang ? 100 : 0;
  const eraPct = Math.max(0, Math.round(100 - Math.abs(source.year - candidate.year) * 4));

  // Weighted normalized composite Match Index (0..100)
  const totalWeight = Math.max(
    1,
    weights.genre + weights.director + weights.cast + weights.story + weights.cross + weights.era
  );

  const metadataContribution = Math.round((metadataPct * metaWeightSum) / totalWeight);
  const storyContribution = Math.round((storyPct * weights.story) / totalWeight);
  const bridgeContribution = Math.round((bridgePct * weights.cross) / totalWeight);
  const eraContribution = Math.round((eraPct * weights.era) / totalWeight);

  const score = Math.min(
    100,
    metadataContribution + storyContribution + bridgeContribution + eraContribution
  );

  const reasons: string[] = [];
  if (sharedGenres.length > 0) {
    reasons.push(`Metadata: ${sharedGenres.join(', ')}`);
  }
  if (sameDirector) {
    reasons.push(`Same director: ${candidate.director}`);
  }
  if (sharedCast.length > 0) {
    reasons.push(`Shared cast: ${sharedCast.join(', ')}`);
  }
  if (sharedTerms.length > 0) {
    reasons.push(`Story terms: ${sharedTerms.slice(0, 3).join(', ')}`);
  }
  if (source.lang !== candidate.lang) {
    reasons.push(`${source.lang} → ${candidate.lang} bridge`);
  }
  if (Math.abs(source.year - candidate.year) <= 6) {
    reasons.push(`Same era (${candidate.year})`);
  }

  return {
    movie: candidate,
    score,
    breakdown: {
      metadataPct,
      storyPct,
      bridgePct,
      eraPct,
      metadataContribution,
      storyContribution,
      bridgeContribution,
      eraContribution,
    },
    sharedGenres,
    sharedCast,
    sameDirector,
    sharedStoryTerms: sharedTerms,
    reasons: reasons.length
      ? reasons
      : [`Archive rating ★ ${candidate.rating.toFixed(1)} (${candidate.lang})`],
  };
}

export function getCrossIndustryTwins(
  movie: Movie,
  allMovies: Movie[],
  weights: AlgoWeights,
  limit = 3
): SimilarityMatch[] {
  const results: SimilarityMatch[] = [];
  for (const cand of allMovies) {
    const res = computeSimilarity(movie, cand, weights, allMovies, true);
    if (res) results.push(res);
  }
  results.sort(
    (a, b) =>
      b.score - a.score ||
      b.breakdown.metadataPct - a.breakdown.metadataPct ||
      b.movie.rating - a.movie.rating
  );
  return results.slice(0, limit);
}

export interface IndustryTheme {
  bannerGradient: string;
  accentHex: string;
  accentTextClass: string;
  barClass: string;
  regionLabel: string;
}

export const INDUSTRY_THEMES: Record<Industry, IndustryTheme> = {
  Hindi: {
    bannerGradient: 'from-[#4a180d] via-[#1c100d] to-[#0d0e14]',
    accentHex: '#e5a93c',
    accentTextClass: 'text-amber-400',
    barClass: 'bg-amber-400',
    regionLabel: 'Hindi Cinema',
  },
  Malayalam: {
    bannerGradient: 'from-[#063d2d] via-[#0b1f1c] to-[#0d0e14]',
    accentHex: '#34d399',
    accentTextClass: 'text-emerald-400',
    barClass: 'bg-emerald-400',
    regionLabel: 'Mollywood',
  },
  Tamil: {
    bannerGradient: 'from-[#4f124d] via-[#1f0e22] to-[#0d0e14]',
    accentHex: '#f472b6',
    accentTextClass: 'text-pink-400',
    barClass: 'bg-pink-400',
    regionLabel: 'Kollywood',
  },
  Telugu: {
    bannerGradient: 'from-[#523007] via-[#21170a] to-[#0d0e14]',
    accentHex: '#fbbf24',
    accentTextClass: 'text-yellow-400',
    barClass: 'bg-yellow-400',
    regionLabel: 'Tollywood',
  },
  Kannada: {
    bannerGradient: 'from-[#5c1118] via-[#220d11] to-[#0d0e14]',
    accentHex: '#fb7185',
    accentTextClass: 'text-rose-400',
    barClass: 'bg-rose-400',
    regionLabel: 'Sandalwood',
  },
};
