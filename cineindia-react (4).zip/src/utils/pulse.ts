import type { ComputedPulse, UserVerdictTally, VerdictType } from '../types/movie';

export const MIN_PULSE_VOTES = 3;

export const EMPTY_TALLY: UserVerdictTally = {
  perfection: 0,
  goforit: 0,
  timepass: 0,
  skip: 0,
};

const TIERS: VerdictType[] = ['perfection', 'goforit', 'timepass', 'skip'];

/**
 * Largest-remainder rounding so non-empty tier percentages sum strictly to 100%.
 */
export function roundPercentagesTo100(
  tally: UserVerdictTally,
  total: number
): Record<VerdictType, number> {
  if (total <= 0) {
    return { perfection: 0, goforit: 0, timepass: 0, skip: 0 };
  }

  const exact = TIERS.map((tier) => {
    const raw = (tally[tier] / total) * 100;
    return {
      tier,
      floor: Math.floor(raw),
      remainder: raw - Math.floor(raw),
    };
  });

  let remaining = 100 - exact.reduce((sum, item) => sum + item.floor, 0);
  const byRemainder = [...exact].sort((a, b) => b.remainder - a.remainder);

  for (let i = 0; i < remaining; i += 1) {
    byRemainder[i % byRemainder.length].floor += 1;
  }

  const out: Record<VerdictType, number> = {
    perfection: 0,
    goforit: 0,
    timepass: 0,
    skip: 0,
  };
  for (const item of exact) {
    out[item.tier] = item.floor;
  }
  return out;
}

export function computeDynamicPulse(
  tally: UserVerdictTally | undefined,
  userPick: VerdictType | null = null
): ComputedPulse {
  const safe: UserVerdictTally = tally ?? EMPTY_TALLY;
  const totalVotes = safe.perfection + safe.goforit + safe.timepass + safe.skip;
  const hasSufficientData = totalVotes >= MIN_PULSE_VOTES;

  return {
    tally: safe,
    totalVotes,
    hasSufficientData,
    minVotesRequired: MIN_PULSE_VOTES,
    percentages: hasSufficientData ? roundPercentagesTo100(safe, totalVotes) : null,
    userPick,
  };
}

/**
 * Casts, switches, or toggles off a user's single verdict for a film.
 */
export function applyUserVote(
  prevTally: UserVerdictTally | undefined,
  prevPick: VerdictType | null,
  nextPick: VerdictType
): { tally: UserVerdictTally; userPick: VerdictType | null } {
  const next: UserVerdictTally = { ...(prevTally ?? EMPTY_TALLY) };

  if (prevPick === nextPick) {
    next[prevPick] = Math.max(0, next[prevPick] - 1);
    return { tally: next, userPick: null };
  }

  if (prevPick) {
    next[prevPick] = Math.max(0, next[prevPick] - 1);
  }

  next[nextPick] += 1;
  return { tally: next, userPick: nextPick };
}
