import React from 'react';
import { Search, X, Gem, RotateCcw, Bookmark } from 'lucide-react';
import type {
  CatalogStats,
  EraOption,
  Industry,
  ParsedQuery,
  SortOption,
} from '../types/movie';
import { INDUSTRIES } from '../utils/recommender';

interface FilterBarProps {
  catalogStats: CatalogStats;
  searchQuery: string;
  onSearchChange: (val: string) => void;
  searchInputRef: React.RefObject<HTMLInputElement | null>;
  activeIndustry: Industry | 'ALL';
  onIndustryChange: (lang: Industry | 'ALL') => void;
  activeGenre: string;
  onGenreChange: (genre: string) => void;
  era: EraOption;
  onEraChange: (era: EraOption) => void;
  sortBy: SortOption;
  onSortChange: (sort: SortOption) => void;
  hiddenGemsOnly: boolean;
  onToggleHiddenGems: () => void;
  watchlistOnly: boolean;
  watchlistCount: number;
  onToggleWatchlistOnly: () => void;
  nlpParsed: ParsedQuery | null;
  filteredBeforeSearchCount: number;
  searchResultCount: number;
  onResetAll: () => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  catalogStats,
  searchQuery,
  onSearchChange,
  searchInputRef,
  activeIndustry,
  onIndustryChange,
  activeGenre,
  onGenreChange,
  era,
  onEraChange,
  sortBy,
  onSortChange,
  hiddenGemsOnly,
  onToggleHiddenGems,
  watchlistOnly,
  watchlistCount,
  onToggleWatchlistOnly,
  nlpParsed,
  filteredBeforeSearchCount,
  searchResultCount,
  onResetAll,
}) => {
  const hasSearch = searchQuery.trim().length > 0;
  const hasActiveFilters =
    activeIndustry !== 'ALL' ||
    activeGenre !== 'ALL' ||
    era !== 'ALL' ||
    hiddenGemsOnly ||
    watchlistOnly;

  const hasNlpDetails =
    nlpParsed &&
    (nlpParsed.lang ||
      nlpParsed.maxRuntime ||
      nlpParsed.minYear ||
      nlpParsed.keywords.length > 0 ||
      nlpParsed.mappedFromScript);

  return (
    <section id="catalog-grid" className="mx-auto max-w-7xl px-4 pt-7 pb-4 sm:px-6">
      {/* Master Search Bar */}
      <div className="relative flex items-center rounded-xl border border-white/12 bg-[#0d0f15] transition-colors focus-within:border-amber-400/70">
        <Search className="ml-4 h-4 w-4 shrink-0 text-[#868da3]" />
        <input
          ref={searchInputRef}
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search Khosla Ka Ghosla, 12th Fail, Dhurandhar, 1970s Hindi, Malayalam under 2 hours..."
          aria-label="Search films, directors, cast, or decades"
          className="w-full bg-transparent px-3.5 py-3 text-sm text-[#f4f1ea] placeholder-[#687087] focus:outline-none"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => onSearchChange('')}
            aria-label="Clear search"
            className="mr-3 rounded-md p-1.5 text-[#8f97ad] transition hover:bg-white/10 hover:text-[#f4f1ea] cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Parsed Query Feedback Line */}
      {hasNlpDetails && nlpParsed && (
        <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-white/[0.08] pb-2.5 text-xs text-[#b4bacb]">
          <span className="font-semibold text-amber-400">Active Query</span>
          {nlpParsed.mappedFromScript && (
            <span>
              Matched: <strong className="text-[#f4f1ea]">{nlpParsed.mappedFromScript}</strong>
            </span>
          )}
          {nlpParsed.lang && (
            <span>
              Industry: <strong className="text-[#f4f1ea]">{nlpParsed.lang}</strong>
            </span>
          )}
          {nlpParsed.minYear && nlpParsed.maxYear && (
            <span className="font-mono-tabular">
              Decade: <strong className="text-[#f4f1ea]">{nlpParsed.minYear}–{nlpParsed.maxYear}</strong>
            </span>
          )}
          {nlpParsed.maxRuntime && (
            <span className="font-mono-tabular">
              Runtime: <strong className="text-[#f4f1ea]">≤ {nlpParsed.maxRuntime}m</strong>
            </span>
          )}
          {nlpParsed.keywords.length > 0 && (
            <span>
              Keywords:{' '}
              <strong className="text-[#f4f1ea]">
                {Array.from(new Set(nlpParsed.keywords)).join(', ')}
              </strong>
            </span>
          )}
        </div>
      )}

      {/* Segmented Industry Controls & Dropdown Filters */}
      <div className="mt-4 flex flex-col justify-between gap-3 lg:flex-row lg:items-center">
        <div
          role="tablist"
          aria-label="Filter by Indian film industry"
          className="flex flex-wrap items-center gap-1 rounded-lg border border-white/[0.08] bg-[#0d0f15] p-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeIndustry === 'ALL'}
            onClick={() => onIndustryChange('ALL')}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
              activeIndustry === 'ALL'
                ? 'bg-[#f4f1ea] text-[#090a0d]'
                : 'text-[#9ea4b8] hover:text-[#f4f1ea]'
            }`}
          >
            All Films
          </button>
          {INDUSTRIES.map((lang) => (
            <button
              key={lang}
              type="button"
              role="tab"
              aria-selected={activeIndustry === lang}
              onClick={() => onIndustryChange(lang)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                activeIndustry === lang
                  ? 'bg-[#f4f1ea] text-[#090a0d]'
                  : 'text-[#9ea4b8] hover:text-[#f4f1ea]'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={activeGenre}
            onChange={(e) => onGenreChange(e.target.value)}
            aria-label="Filter by genre"
            className="rounded-lg border border-white/12 bg-[#0d0f15] px-3 py-2 text-xs font-medium text-[#e6e3db] focus:border-amber-400/70 focus:outline-none cursor-pointer"
          >
            <option value="ALL">All Genres ({catalogStats.allGenres.length})</option>
            {catalogStats.allGenres.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>

          <select
            value={era}
            onChange={(e) => onEraChange(e.target.value as EraOption)}
            aria-label="Filter by era"
            className="rounded-lg border border-white/12 bg-[#0d0f15] px-3 py-2 text-xs font-medium text-[#e6e3db] focus:border-amber-400/70 focus:outline-none cursor-pointer"
          >
            <option value="ALL">All Eras ({catalogStats.minYear}–{catalogStats.maxYear})</option>
            <option value="2020s">2020s &amp; {catalogStats.maxYear} Slate</option>
            <option value="2010s">2010s Modern Wave</option>
            <option value="2000s">2000s Transition</option>
            <option value="1990s">1990s Turning Point</option>
            <option value="1980s">1980s New Wave</option>
            <option value="Classic">{catalogStats.minYear}–1979 Golden Age</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value as SortOption)}
            aria-label="Sort films"
            className="rounded-lg border border-white/12 bg-[#0d0f15] px-3 py-2 text-xs font-medium text-[#e6e3db] focus:border-amber-400/70 focus:outline-none cursor-pointer"
          >
            <option value="rating">Sort: Top Rated</option>
            <option value="perfection">Sort: Top Masterpieces</option>
            <option value="gems">Sort: Hidden Gems</option>
            <option value="newest">Sort: Newest First ({catalogStats.maxYear})</option>
            <option value="oldest">Sort: Oldest First ({catalogStats.minYear})</option>
            <option value="runtime">Sort: Shortest Runtime</option>
          </select>

          <button
            type="button"
            onClick={onToggleHiddenGems}
            title="High-rated films waiting to be discovered"
            className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
              hiddenGemsOnly
                ? 'border-emerald-400/70 bg-emerald-500/15 text-emerald-300'
                : 'border-white/12 bg-[#0d0f15] text-[#b4bacb] hover:border-emerald-400/40 hover:text-emerald-300'
            }`}
          >
            <Gem className="h-3.5 w-3.5" />
            <span>Hidden Gems</span>
          </button>

          <button
            type="button"
            onClick={onToggleWatchlistOnly}
            className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
              watchlistOnly
                ? 'border-amber-400 bg-amber-400/15 text-amber-300'
                : 'border-white/12 bg-[#0d0f15] text-[#b4bacb] hover:border-amber-400/50 hover:text-amber-300'
            }`}
          >
            <Bookmark className={`h-3.5 w-3.5 ${watchlistOnly ? 'fill-current' : ''}`} />
            <span>Watchlist ({watchlistCount})</span>
          </button>

          {(hasActiveFilters || hasSearch) && (
            <button
              type="button"
              onClick={onResetAll}
              className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-transparent px-2.5 py-2 text-xs font-medium text-[#9aa2b8] whitespace-nowrap transition hover:border-white/25 hover:text-[#f4f1ea] cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Clean Film Count Status Strip */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.08] pb-3 text-xs text-[#8b92a8]">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 font-mono-tabular">
          <span>
            Catalog: <strong className="text-[#f4f1ea]">{catalogStats.totalCount}</strong> films
          </span>
          {hasActiveFilters && (
            <>
              <span aria-hidden="true">·</span>
              <span>
                Filtered: <strong className="text-amber-300">{filteredBeforeSearchCount}</strong>
              </span>
            </>
          )}
          {hasSearch && (
            <>
              <span aria-hidden="true">·</span>
              <span>
                Matches: <strong className="text-emerald-400">{searchResultCount}</strong>
              </span>
            </>
          )}
        </div>

        <span className="text-[11px] text-[#7e859c]">
          Click any film for synopsis, cast, teaser &amp; reviews
        </span>
      </div>
    </section>
  );
};
