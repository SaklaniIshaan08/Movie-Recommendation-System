import React, { useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Bookmark, Check, Plus, GitCompareArrows, Gem } from 'lucide-react';
import type { HiddenGemMetrics, Movie, UserVerdictTally, VerdictType } from '../types/movie';
import { POSTER_URLS } from '../data/posters';
import { computeDynamicPulse } from '../utils/pulse';
import { INDUSTRY_THEMES } from '../utils/recommender';

interface MovieCardProps {
  movie: Movie;
  gemMetrics: HiddenGemMetrics;
  verdictTally?: UserVerdictTally;
  userPick?: VerdictType | null;
  showGemMetrics?: boolean;
  inDna: boolean;
  inCompare: boolean;
  inWatchlist: boolean;
  index?: number;
  onInspect: (movie: Movie) => void;
  onToggleDna: (movieId: number) => void;
  onToggleCompare: (movieId: number) => void;
  onToggleWatchlist: (movieId: number) => void;
}

export const MovieCard: React.FC<MovieCardProps> = ({
  movie,
  gemMetrics,
  verdictTally,
  userPick = null,
  showGemMetrics = false,
  inDna,
  inCompare,
  inWatchlist,
  index = 0,
  onInspect,
  onToggleDna,
  onToggleCompare,
  onToggleWatchlist,
}) => {
  const theme = INDUSTRY_THEMES[movie.lang];
  const posterUrl = POSTER_URLS[movie.id];
  const pulse = computeDynamicPulse(verdictTally, userPick);
  const [imgFailed, setImgFailed] = useState(false);
  const [tilt, setTilt] = useState<{ rx: number; ry: number; gx: number; gy: number; active: boolean }>({
    rx: 0,
    ry: 0,
    gx: 50,
    gy: 30,
    active: false,
  });
  const cardRef = useRef<HTMLElement | null>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    const el = cardRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    const ry = (px - 0.5) * 7;
    const rx = (0.5 - py) * 7;
    setTilt({
      rx,
      ry,
      gx: Math.round(px * 100),
      gy: Math.round(py * 100),
      active: true,
    });
  };

  const handleMouseLeave = () => {
    setTilt({ rx: 0, ry: 0, gx: 50, gy: 30, active: false });
  };

  const showPosterImage = Boolean(posterUrl) && !imgFailed;

  return (
    <motion.article
      ref={cardRef}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.28,
        delay: Math.min(index * 0.015, 0.22),
        ease: [0.16, 1, 0.3, 1],
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={() => onInspect(movie)}
      style={{
        transform: tilt.active
          ? `perspective(950px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg) translateY(-6px)`
          : 'perspective(950px) rotateX(0deg) rotateY(0deg) translateY(0px)',
      }}
      className="group relative flex cursor-pointer flex-col overflow-hidden rounded-xl border border-white/[0.09] bg-[#0b0c11] transition-[transform,border-color,box-shadow] duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] hover:border-amber-400/55 hover:shadow-[0_24px_55px_rgba(0,0,0,0.75)]"
    >
      {/* Dynamic Cursor Glint Highlight */}
      {tilt.active && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-30 opacity-80 transition-opacity duration-200"
          style={{
            background: `radial-gradient(280px circle at ${tilt.gx}% ${tilt.gy}%, rgba(251, 191, 36, 0.14), transparent 70%)`,
          }}
        />
      )}

      {/* Original 2:3 Film Poster Container */}
      <div
        className={`relative aspect-[2/3] w-full overflow-hidden bg-gradient-to-br ${theme.bannerGradient}`}
      >
        {showPosterImage ? (
          <img
            src={posterUrl}
            alt={`${movie.title} (${movie.year}) poster`}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="h-full w-full object-cover object-center transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.06]"
          />
        ) : (
          <div className="flex h-full w-full flex-col justify-between p-4">
            <div className="pointer-events-none absolute inset-3 border border-white/[0.08]" />
            <div className="mt-auto">
              <p className="font-mono-tabular text-[11px] text-[#a7aec2]">{movie.director}</p>
              <h4 className="mt-1 font-display text-xl font-extrabold leading-tight text-[#f7f4ec]">
                {movie.title}
              </h4>
              <p className="mt-1 text-xs text-[#b5bacb]">{movie.native}</p>
            </div>
          </div>
        )}

        {/* Measured Contrast Scrim */}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0b0c11] via-[#0b0c11]/25 to-black/55" />

        {/* Top Poster Bar: Star Rating + Watchlist Bookmark */}
        <div className="absolute inset-x-3 top-3 z-20 flex items-center justify-between gap-2">
          <span
            title={gemMetrics.qualifies ? `Hidden Gem · Rated ★ ${movie.rating.toFixed(1)}` : `Rated ★ ${movie.rating.toFixed(1)}`}
            className="inline-flex items-center gap-1 rounded-md bg-black/75 px-2 py-1 font-mono-tabular text-[11px] font-bold text-amber-300 backdrop-blur-md"
          >
            {gemMetrics.qualifies && <Gem className="h-3 w-3 text-emerald-400" />}
            <span>★ {movie.rating.toFixed(1)}</span>
          </span>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleWatchlist(movie.id);
            }}
            aria-label={inWatchlist ? `Remove ${movie.title} from watchlist` : `Save ${movie.title} to watchlist`}
            className={`rounded-md border p-1.5 backdrop-blur-md transition cursor-pointer ${
              inWatchlist
                ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                : 'border-white/20 bg-black/65 text-[#e6e3db] hover:border-amber-400/70 hover:text-amber-300'
            }`}
          >
            <Bookmark className={`h-3.5 w-3.5 ${inWatchlist ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Interactive Hover Synopsis + Action Overlay */}
        <div className="absolute inset-x-0 bottom-0 z-20 flex flex-col justify-end bg-gradient-to-t from-[#090a0d] via-[#090a0d]/92 to-transparent p-3.5 pt-10 opacity-100 sm:translate-y-3 sm:opacity-0 transition-all duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-y-0 group-hover:opacity-100">
          <p className="hidden sm:line-clamp-2 text-[11px] leading-relaxed text-[#d3d7e4] mb-2.5">
            {movie.synopsis}
          </p>

          <div
            onClick={(e) => e.stopPropagation()}
            className="flex items-center gap-1.5"
          >
            <button
              type="button"
              onClick={() => onToggleCompare(movie.id)}
              className={`inline-flex flex-1 items-center justify-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-semibold transition cursor-pointer ${
                inCompare
                  ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                  : 'border-white/20 bg-[#141722]/90 text-[#f4f1ea] hover:border-amber-400/70 hover:text-amber-300'
              }`}
            >
              <GitCompareArrows className="h-3 w-3" />
              <span>{inCompare ? 'Queued' : 'Compare'}</span>
            </button>

            <button
              type="button"
              onClick={() => onToggleDna(movie.id)}
              className={`inline-flex flex-1 items-center justify-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-semibold transition cursor-pointer ${
                inDna
                  ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                  : 'border-white/20 bg-[#141722]/90 text-[#f4f1ea] hover:border-amber-400/70 hover:text-amber-300'
              }`}
            >
              {inDna ? <Check className="h-3 w-3" /> : <Plus className="h-3 w-3" />}
              <span>{inDna ? 'In DNA' : 'Test DNA'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Crisp Unboxed Editorial Card Footer */}
      <div className="flex flex-1 flex-col justify-between gap-2 p-3.5">
        <div>
          <div className="flex items-center justify-between gap-2 font-mono-tabular text-[11px]">
            <span className="truncate font-medium text-[#b4bacb]">
              <span className={theme.accentTextClass}>{movie.lang}</span> · {movie.year} · {movie.runtime}m
            </span>
          </div>

          <h3 className="mt-1 line-clamp-1 font-display text-base font-extrabold tracking-tight text-[#f7f4ec] transition-colors group-hover:text-amber-300">
            {movie.title}
          </h3>

          <p className="mt-0.5 truncate text-[11px] text-[#8b92a8]">
            {movie.director} · {movie.genres.slice(0, 2).join(', ')}
          </p>

          {showGemMetrics && gemMetrics.qualifies && (
            <p className="mt-1 inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400">
              <Gem className="h-3 w-3" />
              <span>Under-seen Gem</span>
            </p>
          )}
        </div>

        {/* Clean Consensus Bar (only shown once community votes reach threshold) */}
        {pulse.hasSufficientData && pulse.percentages && (
          <div className="space-y-1 pt-0.5">
            <div className="flex items-center justify-between font-mono-tabular text-[10px] font-semibold">
              <span className="text-emerald-400">{pulse.percentages.perfection}% Masterpiece</span>
              <span className="text-[#9ea4b8]">{pulse.totalVotes} votes</span>
            </div>
            <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-white/[0.07]">
              <div className="h-full bg-emerald-400" style={{ width: `${pulse.percentages.perfection}%` }} />
              <div className="h-full bg-amber-400" style={{ width: `${pulse.percentages.goforit}%` }} />
              <div className="h-full bg-sky-400" style={{ width: `${pulse.percentages.timepass}%` }} />
              <div className="h-full bg-rose-500" style={{ width: `${pulse.percentages.skip}%` }} />
            </div>
          </div>
        )}
      </div>
    </motion.article>
  );
};
