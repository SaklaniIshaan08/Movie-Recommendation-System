import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, ArrowRight, UserCheck, Bookmark, Dna } from 'lucide-react';

export interface AuthUser {
  name: string;
  email: string;
}

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onAuthenticated: (user: AuthUser) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  open,
  onClose,
  onAuthenticated,
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedEmail = email.trim().toLowerCase();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setError('Enter a valid email address.');
      return;
    }
    if (password.length < 4) {
      setError('Password must be at least 4 characters.');
      return;
    }

    try {
      const raw = window.localStorage.getItem('cineindia_accounts_v1');
      const accounts: Record<string, { name: string; password: string }> = raw
        ? JSON.parse(raw)
        : {};

      if (mode === 'signup') {
        const displayName = name.trim() || trimmedEmail.split('@')[0];
        accounts[trimmedEmail] = { name: displayName, password };
        window.localStorage.setItem('cineindia_accounts_v1', JSON.stringify(accounts));
        onAuthenticated({ name: displayName, email: trimmedEmail });
        onClose();
        return;
      }

      // Sign In
      const existing = accounts[trimmedEmail];
      if (existing) {
        if (existing.password !== password) {
          setError('Incorrect password for this account.');
          return;
        }
        onAuthenticated({ name: existing.name, email: trimmedEmail });
        onClose();
        return;
      }

      // If first-time sign-in with valid credentials, register smoothly for zero-friction preview
      const fallbackName = trimmedEmail.split('@')[0];
      accounts[trimmedEmail] = { name: fallbackName, password };
      window.localStorage.setItem('cineindia_accounts_v1', JSON.stringify(accounts));
      onAuthenticated({ name: fallbackName, email: trimmedEmail });
      onClose();
    } catch {
      onAuthenticated({
        name: name.trim() || trimmedEmail.split('@')[0] || 'Cinephile',
        email: trimmedEmail,
      });
      onClose();
    }
  };

  const handleGuestPass = () => {
    onAuthenticated({ name: 'Guest_Cinephile', email: 'guest@cineindia.in' });
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Sign in to CineIndia"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 14 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md overflow-hidden rounded-2xl border border-white/12 bg-[#0b0c11] p-6 shadow-[0_32px_90px_rgba(0,0,0,0.9)] sm:p-7"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close sign in dialog"
          className="absolute top-4 right-4 rounded-lg border border-white/12 bg-[#141720] p-1.5 text-[#cbd0de] transition hover:border-amber-400/60 hover:text-[#f4f1ea] cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>

        <div>
          <p className="font-mono-tabular text-[11px] font-semibold tracking-[0.14em] text-amber-400">
            Member Access
          </p>
          <h2 className="mt-1 font-display text-2xl font-extrabold tracking-tight text-[#f4f1ea]">
            {mode === 'login' ? 'Sign in to CineIndia' : 'Create your CineIndia pass'}
          </h2>
          <p className="mt-1.5 text-xs leading-relaxed text-[#9ca3b8]">
            Save your personal watchlist, sync Test DNA blends, and publish verified audience reviews.
          </p>
        </div>

        {/* Segmented Auth Mode */}
        <div className="mt-5 grid grid-cols-2 gap-1 rounded-lg border border-white/[0.08] bg-[#060608] p-1">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError(null);
            }}
            className={`rounded-md py-2 text-xs font-semibold transition cursor-pointer ${
              mode === 'login'
                ? 'bg-[#f4f1ea] text-[#090a0d]'
                : 'text-[#9ea4b8] hover:text-[#f4f1ea]'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setError(null);
            }}
            className={`rounded-md py-2 text-xs font-semibold transition cursor-pointer ${
              mode === 'signup'
                ? 'bg-[#f4f1ea] text-[#090a0d]'
                : 'text-[#9ea4b8] hover:text-[#f4f1ea]'
            }`}
          >
            Create Account
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
          {mode === 'signup' && (
            <div>
              <label className="mb-1.5 block text-xs font-medium text-[#b4bacb]">
                Display Handle
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ishaan_Cinema"
                className="w-full rounded-lg border border-white/12 bg-[#060608] px-3.5 py-2.5 text-sm text-[#f4f1ea] placeholder-[#5e657a] focus:border-amber-400/70 focus:outline-none"
              />
            </div>
          )}

          <div>
            <label className="mb-1.5 block text-xs font-medium text-[#b4bacb]">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@domain.com"
              required
              className="w-full rounded-lg border border-white/12 bg-[#060608] px-3.5 py-2.5 text-sm text-[#f4f1ea] placeholder-[#5e657a] focus:border-amber-400/70 focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-medium text-[#b4bacb]">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 4 characters"
              required
              className="w-full rounded-lg border border-white/12 bg-[#060608] px-3.5 py-2.5 text-sm text-[#f4f1ea] placeholder-[#5e657a] focus:border-amber-400/70 focus:outline-none"
            />
          </div>

          {error && (
            <p className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">
              {error}
            </p>
          )}

          <button
            type="submit"
            className="mt-1 flex w-full items-center justify-center gap-2 rounded-lg bg-amber-400 px-4 py-2.5 text-xs font-bold text-[#090a0d] transition hover:bg-amber-300 cursor-pointer"
          >
            <span>{mode === 'login' ? 'Sign In & Sync Profile' : 'Create CineIndia Pass'}</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </form>

        <div className="my-4 flex items-center gap-3 text-xs text-[#697086]">
          <div className="h-px flex-1 bg-white/10" />
          <span>or</span>
          <div className="h-px flex-1 bg-white/10" />
        </div>

        <button
          type="button"
          onClick={handleGuestPass}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-white/14 bg-[#060608] px-4 py-2.5 text-xs font-semibold text-[#e6e3db] transition hover:border-amber-400/50 hover:text-amber-300 cursor-pointer"
        >
          <UserCheck className="h-4 w-4 text-amber-400" />
          <span>Continue with 1-Click Guest Pass</span>
        </button>

        <div className="mt-5 flex items-center justify-between border-t border-white/[0.08] pt-3.5 text-[11px] text-[#7e859c]">
          <span className="inline-flex items-center gap-1.5">
            <Bookmark className="h-3.5 w-3.5 text-amber-400" />
            Watchlist sync
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Dna className="h-3.5 w-3.5 text-emerald-400" />
            Saved Test DNA
          </span>
        </div>
      </motion.div>
    </div>
  );
};
