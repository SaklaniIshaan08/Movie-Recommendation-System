import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { GitCompareArrows, X, ArrowRight, Plus, Check } from 'lucide-react';
import type { AlgoWeights, Movie, UserVerdictTally, VerdictType } from '../types/movie';
import { POSTER_URLS } from '../data/posters';
import { computeDynamicPulse } from '../utils/pulse';
import { computeSimilarity, INDUSTRY_THEMES } from '../utils/recommender';

interface CompareLabProps {
  open: boolean;
  allMovies: Movie[];
  compareIds: number[];
  weights: AlgoWeights;
  verdictTallies: Record<number, UserVerdictTally>;
  userPicks: Record<number, VerdictType>;
  onClose: () => void;
  onSetCompareIds: (ids: number[]) => void;
  onToggleCompare: (movieId: number) => void;
  onInspectMovie: (movie: Movie) => void;
}

const CURATED_MATCHUPS: Array<{ label: string; titles: [string, string] }> = [
  { label: 'Dhurandhar vs Jawan', titles: ['Dhurandhar', 'Jawan'] },
  { label: 'Drishyam: Malayalam vs Hindi', titles: ['Drishyam', 'Drishyam 2015'] },
  { label: 'Sholay vs Deewaar (1975)', titles: ['Sholay', 'Deewaar'] },
  { label: 'Bramayugam vs Tumbbad', titles: ['Bramayugam', 'Tumbbad'] },
];

export const CompareDock: React.FC<{
  movies: Movie[];
  onRemove: (id: number) => void;
  onOpenLab: () => void;
  onClear: () => void;
}> = ({ movies, onRemove, onOpenLab, onClear }) => {
  if (movies.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 24 }}
      className="fixed bottom-4 left-1/2 z-30 w-[calc(100%-2rem)] max-w-2xl -translate-x-1/2 rounded-xl border border-amber-400/40 bg-[#0d0f16]/95 p-3 shadow-[0_24px_60px_rgba(0,0,0,0.85)] backdrop-blur-xl"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400">
            <GitCompareArrows className="h-3.5 w-3.5" />
            <span>Compare ({movies.length}/3)</span>
          </span>
          {movies.map((m) => (
            <span
              key={m.id}
              className="inline-flex items-center gap-1.5 rounded-md border border-white/15 bg-[#151824] px-2.5 py-1 text-xs font-medium text-[#f4f1ea]"
            >
              <span className="max-w-[140px] truncate">{m.title}</span>
              <button
                type="button"
                onClick={() => onRemove(m.id)}
                aria-label={`Remove ${m.title} from comparison`}
                className="text-[#8f97ad] hover:text-rose-300 cursor-pointer"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onClear}
            className="px-2 py-1 text-xs font-medium text-[#9096ab] hover:text-[#f4f1ea] cursor-pointer"
          >
            Clear
          </button>
          <button
            type="button"
            onClick={onOpenLab}
            className="inline-flex items-center gap-1.5 rounded-lg bg-amber-400 px-3.5 py-1.5 text-xs font-bold text-[#090a0d] transition hover:bg-amber-300 cursor-pointer"
          >
            <span>{movies.length >= 2 ? 'Compare Side-by-Side' : 'Pick 2nd Film'}</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export const CompareLabModal: React.FC<CompareLabProps> = ({
  open,
  allMovies,
  compareIds,
  weights,
  verdictTallies,
  userPicks,
  onClose,
  onSetCompareIds,
  onToggleCompare,
  onInspectMovie,
}) => {
  const [pickerQuery, setPickerQuery] = useState('');

  const activeMovies = useMemo(() => {
    const selected = compareIds
      .map((id) => allMovies.find((m) => m.id === id))
      .filter((m): m is Movie => Boolean(m));
    if (selected.length >= 2) return selected;

    const defaults = ['Dhurandhar', 'Jawan']
      .map((title) => allMovies.find((m) => m.title.toLowerCase() === title.toLowerCase()))
      .filter((m): m is Movie => Boolean(m));

    if (selected.length === 1) {
      const partner = defaults.find((d) => d.id !== selected[0].id) || allMovies[1];
      return [selected[0], partner];
    }
    return defaults;
  }, [compareIds, allMovies]);

  const pickerResults = useMemo(() => {
    const q = pickerQuery.trim().toLowerCase();
    const list = q
      ? allMovies.filter(
          (m) =>
            m.title.toLowerCase().includes(q) ||
            m.hinglish.toLowerCase().includes(q) ||
            m.director.toLowerCase().includes(q) ||
            m.lang.toLowerCase().includes(q)
        )
      : allMovies.slice(0, 24);
    return list.slice(0, 12);
  }, [allMovies, pickerQuery]);

  const pairwiseInsight = useMemo(() => {
    if (activeMovies.length < 2) return null;
    const [a, b] = activeMovies;
    const sim = computeSimilarity(a, b, weights, allMovies, false);
    const sharedGenres = a.genres.filter((g) => b.genres.includes(g));
    const sharedCast = a.cast.filter((c) => b.cast.includes(c));
    const yearGap = Math.abs(a.year - b.year);
    const runtimeDiff = Math.abs(a.runtime - b.runtime);

    return {
      a,
      b,
      sharedGenres,
      sharedCast,
      yearGap,
      runtimeDiff,
      matchIndex: sim?.score ?? 0,
      breakdown: sim?.breakdown ?? null,
      sharedStoryTerms: sim?.sharedStoryTerms ?? [],
    };
  }, [activeMovies, weights, allMovies]);

  if (!open) return null;

  const maxRuntime = Math.max(...activeMovies.map((m) => m.runtime), 180);
  const maxVotes = Math.max(...activeMovies.map((m) => m.votes), 10000);

  return (
    <AnimatePresence>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Visual Movie Comparison"
        onClick={onClose}
        className="fixed inset-0 z-40 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.97, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.97 }}
          transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          onClick={(e) => e.stopPropagation()}
          className="relative max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-2xl border border-white/12 bg-[#0b0c11] p-5 shadow-[0_32px_90px_rgba(0,0,0,0.9)] sm:p-7"
        >
          {/* Header */}
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-white/[0.08] pb-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                <GitCompareArrows className="h-4 w-4" />
                <span>Visual Cinema Comparison</span>
              </div>
              <h2 className="mt-1 font-display text-2xl font-extrabold tracking-tight text-[#f4f1ea]">
                Side-by-Side Film Comparison
              </h2>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close comparison"
              className="rounded-lg border border-white/12 bg-[#141720] p-2 text-[#cbd0de] hover:border-amber-400/60 hover:text-[#f4f1ea] cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Curated Matchup Presets */}
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-[#82889e]">Quick Matchups:</span>
            {CURATED_MATCHUPS.map((matchup) => (
              <button
                key={matchup.label}
                type="button"
                onClick={() => {
                  const found = matchup.titles
                    .map((t) =>
                      allMovies.find((m) => m.title.toLowerCase() === t.toLowerCase())
                    )
                    .filter((m): m is Movie => Boolean(m))
                    .map((m) => m.id);
                  if (found.length >= 2) onSetCompareIds(found);
                }}
                className="rounded-md border border-white/10 bg-[#11131b] px-2.5 py-1 font-medium text-[#d4d8e4] transition hover:border-amber-400/60 hover:text-amber-300 cursor-pointer"
              >
                {matchup.label}
              </button>
            ))}
          </div>

          {/* Side-by-Side Film Columns */}
          <div
            className={`mt-5 grid gap-4 ${
              activeMovies.length === 3 ? 'md:grid-cols-3' : 'md:grid-cols-2'
            }`}
          >
            {activeMovies.map((m) => {
              const theme = INDUSTRY_THEMES[m.lang];
              const poster = POSTER_URLS[m.id];
              const pulse = computeDynamicPulse(verdictTallies[m.id], userPicks[m.id] ?? null);
              const isInQueue = compareIds.includes(m.id);
              const runtimePct = Math.round((m.runtime / maxRuntime) * 100);
              const ratingPct = Math.round((m.rating / 10) * 100);
              const votesPct = Math.max(8, Math.round((m.votes / maxVotes) * 100));

              return (
                <div
                  key={m.id}
                  className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#08090d] overflow-hidden"
                >
                  {/* Visual Mini Poster Header */}
                  <div className={`relative flex items-start gap-3.5 bg-gradient-to-br ${theme.bannerGradient} p-4`}>
                    {poster && (
                      <img
                        src={poster}
                        alt={`${m.title} poster`}
                        referrerPolicy="no-referrer"
                        className="h-24 w-16 shrink-0 rounded-md border border-white/20 object-cover shadow-lg"
                      />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between text-[11px] font-mono-tabular">
                        <span className={`font-semibold ${theme.accentTextClass}`}>
                          {m.lang} · {m.year}
                        </span>
                        {isInQueue && compareIds.length > 2 && (
                          <button
                            type="button"
                            onClick={() => onToggleCompare(m.id)}
                            aria-label={`Remove ${m.title}`}
                            className="rounded p-0.5 text-[#cbd0de] hover:bg-black/40 hover:text-rose-300 cursor-pointer"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onInspectMovie(m);
                        }}
                        className="mt-1.5 block text-left group cursor-pointer"
                      >
                        <h3 className="truncate font-display text-lg font-extrabold text-[#f7f4ec] group-hover:text-amber-300 transition-colors">
                          {m.title}
                        </h3>
                        <p className="truncate text-xs text-[#b5bacb]">{m.native}</p>
                      </button>

                      <p className="mt-1.5 truncate text-xs text-[#d3d7e4]">
                        {m.director} · <span className="text-[#9ea4b8]">{m.genres.join(' · ')}</span>
                      </p>
                    </div>
                  </div>

                  {/* Animated Comparison Bars */}
                  <div className="space-y-4 p-4">
                    <div>
                      <div className="flex items-center justify-between text-xs font-mono-tabular">
                        <span className="text-[#9ea4b8]">Rating</span>
                        <span className="font-bold text-amber-300">★ {m.rating.toFixed(1)} / 10</span>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-white/[0.07]">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${ratingPct}%` }}
                          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                          className="h-full bg-amber-400"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between text-xs font-mono-tabular">
                        <span className="text-[#9ea4b8]">Runtime</span>
                        <span className="font-semibold text-[#f4f1ea]">{m.runtime} mins</span>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-white/[0.07]">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${runtimePct}%` }}
                          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                          className="h-full bg-sky-400"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between text-xs font-mono-tabular">
                        <span className="text-[#9ea4b8]">Popularity</span>
                        <span className="font-semibold text-[#f4f1ea]">{m.votes.toLocaleString()} votes</span>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-white/[0.07]">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${votesPct}%` }}
                          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                          className="h-full bg-emerald-400"
                        />
                      </div>
                    </div>

                    {/* Audience Verdict */}
                    <div className="border-t border-white/[0.07] pt-3">
                      <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold text-[#cfd4e3]">
                        <span>Audience Verdict</span>
                        {pulse.totalVotes > 0 && (
                          <span className="font-mono-tabular text-[#9ea4b8]">
                            {pulse.totalVotes} {pulse.totalVotes === 1 ? 'vote' : 'votes'}
                          </span>
                        )}
                      </div>

                      {pulse.hasSufficientData && pulse.percentages ? (
                        <>
                          <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-white/[0.07]">
                            <div className="h-full bg-emerald-400" style={{ width: `${pulse.percentages.perfection}%` }} />
                            <div className="h-full bg-amber-400" style={{ width: `${pulse.percentages.goforit}%` }} />
                            <div className="h-full bg-sky-400" style={{ width: `${pulse.percentages.timepass}%` }} />
                            <div className="h-full bg-rose-500" style={{ width: `${pulse.percentages.skip}%` }} />
                          </div>
                          <div className="mt-2 grid grid-cols-2 gap-1 font-mono-tabular text-[10px] text-[#9096ab]">
                            <span>Masterpiece: <strong className="text-emerald-400">{pulse.percentages.perfection}%</strong></span>
                            <span>Recommended: <strong className="text-amber-400">{pulse.percentages.goforit}%</strong></span>
                            <span>One-Time: <strong className="text-sky-400">{pulse.percentages.timepass}%</strong></span>
                            <span>Pass: <strong className="text-rose-400">{pulse.percentages.skip}%</strong></span>
                          </div>
                        </>
                      ) : (
                        <p className="text-[11px] text-[#8b92a8]">
                          Click the title to cast your verdict
                        </p>
                      )}
                    </div>

                    <div className="border-t border-white/[0.07] pt-3 text-xs text-[#9ea4b8]">
                      <span className="text-[#f4f1ea] font-medium">Lead Cast:</span>{' '}
                      {m.cast.join(', ')}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Clean Matchup Summary */}
          {pairwiseInsight && (
            <div className="mt-5 rounded-xl border border-white/10 bg-[#08090d] p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-semibold text-amber-400">
                    How They Compare ({pairwiseInsight.a.title} &amp; {pairwiseInsight.b.title})
                  </span>
                  <p className="mt-1 text-xs text-[#b4bacb]">
                    {pairwiseInsight.sharedGenres.length > 0
                      ? `Shared genres: ${pairwiseInsight.sharedGenres.join(', ')}`
                      : 'Distinct genre palettes'}
                    {' · '}
                    {pairwiseInsight.yearGap === 0
                      ? 'Same release year'
                      : `${pairwiseInsight.yearGap} years apart`}
                    {' · '}
                    {pairwiseInsight.runtimeDiff}m runtime diff
                    {pairwiseInsight.sharedStoryTerms.length > 0
                      ? ` · Themes: ${pairwiseInsight.sharedStoryTerms.slice(0, 3).join(', ')}`
                      : ''}
                  </p>
                </div>

                <div className="text-right font-mono-tabular">
                  <div className="text-[11px] text-[#8b92a8]">Similarity</div>
                  <div className="text-lg font-extrabold text-emerald-400">
                    {pairwiseInsight.matchIndex}%
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Add / Swap Film Picker */}
          <div className="mt-5 border-t border-white/[0.08] pt-4">
            <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
              <span className="text-xs font-semibold text-[#e6e3db]">
                Add or Swap Films in Comparison (up to 3)
              </span>
              <input
                type="text"
                value={pickerQuery}
                onChange={(e) => setPickerQuery(e.target.value)}
                placeholder="Search any of 905 films to add (e.g. 12th Fail, Dhurandhar, Kantara)..."
                className="w-full rounded-lg border border-white/12 bg-[#060608] px-3 py-1.5 text-xs text-[#f4f1ea] placeholder-[#687087] focus:border-amber-400/70 focus:outline-none sm:max-w-xs"
              />
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
              {pickerResults.map((m) => {
                const queued = compareIds.includes(m.id);
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onToggleCompare(m.id)}
                    className={`flex items-center justify-between gap-2 rounded-lg border px-2.5 py-2 text-left text-xs transition cursor-pointer ${
                      queued
                        ? 'border-amber-400 bg-amber-400/15 text-amber-200'
                        : 'border-white/10 bg-[#08090d] text-[#d3d7e4] hover:border-white/25'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="truncate font-semibold">{m.title}</div>
                      <div className="truncate font-mono-tabular text-[10px] text-[#8b92a8]">
                        {m.lang} · {m.year}
                      </div>
                    </div>
                    {queued ? (
                      <Check className="h-3.5 w-3.5 shrink-0 text-amber-400" />
                    ) : (
                      <Plus className="h-3.5 w-3.5 shrink-0 text-[#8b92a8]" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
