import React from 'react';
import { Dna, X, RefreshCw, Sliders } from 'lucide-react';
import type { Industry, Movie, SimilarityMatch, TasteDnaProfile } from '../types/movie';
import { POSTER_URLS } from '../data/posters';
import { INDUSTRIES, INDUSTRY_THEMES } from '../utils/recommender';

interface TasteDnaShelfProps {
  profile: TasteDnaProfile | null;
  recommendations: SimilarityMatch[];
  excludedGenres: string[];
  crossIndustryOnly: boolean;
  languageFilter: Industry | 'ALL';
  onInspectMovie: (movie: Movie) => void;
  onToggleExcludeGenre: (genre: string) => void;
  onCycleSeedWeight: (movieId: number) => void;
  onToggleCrossIndustry: () => void;
  onChangeLanguageFilter: (lang: Industry | 'ALL') => void;
  onRegenerate: () => void;
  onClear: () => void;
}

export const TasteDnaShelf: React.FC<TasteDnaShelfProps> = ({
  profile,
  recommendations,
  excludedGenres,
  crossIndustryOnly,
  languageFilter,
  onInspectMovie,
  onToggleExcludeGenre,
  onCycleSeedWeight,
  onToggleCrossIndustry,
  onChangeLanguageFilter,
  onRegenerate,
  onClear,
}) => {
  if (!profile || profile.seeds.length < 3) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 pb-6 sm:px-6">
      <div className="rounded-xl border border-amber-400/35 bg-[#0b0d14] p-5 sm:p-6">
        {/* Header Row */}
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-white/[0.08] pb-4">
          <div>
            <div className="flex items-center gap-2 text-sm font-bold text-amber-300">
              <Dna className="h-4 w-4" />
              <span>Your Test DNA Profile</span>
            </div>
            <p className="mt-1 text-xs text-[#9ea4b8]">
              Built from your {profile.seeds.length} selected films. Click any genre to mute it, pick a recommendation language, or adjust seed weights.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onToggleCrossIndustry}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition cursor-pointer ${
                languageFilter === 'ALL' && crossIndustryOnly
                  ? 'border-emerald-400/70 bg-emerald-500/15 text-emerald-300'
                  : 'border-white/15 bg-[#060608] text-[#cbd0de] hover:border-white/30'
              }`}
            >
              <Sliders className="h-3.5 w-3.5" />
              <span>
                {languageFilter === 'ALL' && crossIndustryOnly
                  ? 'Cross-Industry Only'
                  : 'Cross-Industry Mix'}
              </span>
            </button>

            <button
              type="button"
              onClick={onRegenerate}
              className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/50 bg-amber-400/15 px-3 py-1.5 text-xs font-semibold text-amber-200 transition hover:bg-amber-400/25 cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Regenerate</span>
            </button>

            <button
              type="button"
              onClick={onClear}
              className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-black/30 px-2.5 py-1.5 text-xs font-medium text-[#cbd0de] transition hover:border-white/30 hover:text-[#f4f1ea] cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Taste Signature Grid */}
        <div className="mt-5 grid gap-5 lg:grid-cols-3">
          {/* 1. Genre Distribution */}
          <div className="rounded-lg border border-white/[0.07] bg-[#060608] p-4">
            <div className="flex items-center justify-between text-xs font-semibold text-[#e6e3db]">
              <span>Top Genres</span>
              <span className="font-mono-tabular text-[11px] text-[#7e859c]">Click to mute/unmute</span>
            </div>
            <div className="mt-3 space-y-2">
              {profile.genreDistribution.slice(0, 6).map((g) => {
                const muted = excludedGenres.includes(g.genre);
                return (
                  <button
                    key={g.genre}
                    type="button"
                    onClick={() => onToggleExcludeGenre(g.genre)}
                    className={`block w-full text-left transition cursor-pointer ${
                      muted ? 'opacity-40 line-through' : 'hover:opacity-90'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] font-mono-tabular">
                      <span className="text-[#f4f1ea]">{g.genre}</span>
                      <span className="text-amber-300">{g.pct}%</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-white/[0.07]">
                      <div className="h-full bg-amber-400" style={{ width: `${Math.max(6, g.pct)}%` }} />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Language Share, Storytelling Motifs & Era */}
          <div className="rounded-lg border border-white/[0.07] bg-[#060608] p-4 space-y-4">
            <div>
              <div className="text-xs font-semibold text-[#e6e3db]">Languages &amp; Era</div>
              <div className="mt-2 space-y-1.5">
                {profile.languageDistribution.map((l) => (
                  <div key={l.lang} className="flex items-center justify-between text-[11px] font-mono-tabular">
                    <span className={INDUSTRY_THEMES[l.lang].accentTextClass}>{l.lang}</span>
                    <span className="text-[#cfd4e3]">{l.pct}% ({l.count} {l.count === 1 ? 'film' : 'films'})</span>
                  </div>
                ))}
              </div>
              <div className="mt-2.5 border-t border-white/[0.07] pt-2.5 text-[11px] font-mono-tabular text-[#9ea4b8]">
                Sweet spot: <strong className="text-[#f4f1ea]">{profile.eraProfile.dominantEra}</strong> · Avg runtime: <strong className="text-[#f4f1ea]">{profile.runtimeProfile.weightedAvgMinutes}m</strong>
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-[#e6e3db]">Story Themes &amp; Motifs</div>
              <p className="mt-1.5 text-xs leading-relaxed text-sky-300 font-mono-tabular">
                {profile.storyThemes.length > 0
                  ? profile.storyThemes.map((t) => t.term).join(' · ')
                  : 'Add more films to surface story themes'}
              </p>
            </div>
          </div>

          {/* 3. Selected Seed Films */}
          <div className="rounded-lg border border-white/[0.07] bg-[#060608] p-4">
            <div className="flex items-center justify-between text-xs font-semibold text-[#e6e3db]">
              <span>Your Seed Films</span>
              <span className="font-mono-tabular text-[11px] text-[#7e859c]">Click weight to adjust</span>
            </div>
            <div className="mt-3 space-y-2.5">
              {profile.seeds.map((s) => (
                <div key={s.movie.id} className="flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="truncate font-semibold text-[#f4f1ea]">{s.movie.title}</div>
                    <div className="truncate font-mono-tabular text-[10px] text-[#8b92a8]">
                      {s.contributionPct}% influence · {s.topGenres.slice(0, 2).join(', ')}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onCycleSeedWeight(s.movie.id)}
                    title="Cycle seed emphasis (0.5x → 1x → 1.5x → 2x)"
                    className="shrink-0 rounded border border-amber-400/40 bg-amber-400/10 px-2 py-1 font-mono-tabular text-[11px] font-bold text-amber-300 hover:bg-amber-400/20 cursor-pointer"
                  >
                    {s.weight}×
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Blended Recommendations with Language Filter */}
        <div className="mt-5 border-t border-white/[0.08] pt-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div>
              <span className="font-semibold text-[#f4f1ea]">
                Recommended for Your Test DNA
              </span>
              <span className="ml-2 text-[11px] text-[#8b92a8]">
                {languageFilter === 'ALL'
                  ? 'Mixed across all 5 languages'
                  : `Filtered to ${languageFilter} cinema`}
              </span>
            </div>

            <div
              role="group"
              aria-label="Filter Test DNA recommendations by language"
              className="flex flex-wrap items-center gap-1.5"
            >
              <button
                type="button"
                onClick={() => onChangeLanguageFilter('ALL')}
                className={`rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  languageFilter === 'ALL'
                    ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                    : 'border-white/12 bg-[#060608] text-[#b4bacb] hover:border-white/30 hover:text-[#f4f1ea]'
                }`}
              >
                All Languages (Mix)
              </button>
              {INDUSTRIES.map((lang) => {
                const active = languageFilter === lang;
                return (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => onChangeLanguageFilter(lang)}
                    className={`rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                      active
                        ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                        : 'border-white/12 bg-[#060608] text-[#b4bacb] hover:border-white/30 hover:text-[#f4f1ea]'
                    }`}
                  >
                    {lang}
                  </button>
                );
              })}
            </div>
          </div>

          {recommendations.length > 0 ? (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {recommendations.map(({ movie, score, sharedGenres, sharedStoryTerms }) => {
                const theme = INDUSTRY_THEMES[movie.lang];
                const poster = POSTER_URLS[movie.id];
                return (
                  <button
                    key={movie.id}
                    type="button"
                    onClick={() => onInspectMovie(movie)}
                    className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#060608] p-3 text-left transition hover:-translate-y-0.5 hover:border-amber-400/60 hover:bg-[#11131b] cursor-pointer"
                  >
                    <div className="flex items-start gap-3">
                      {poster && (
                        <img
                          src={poster}
                          alt={`${movie.title} poster`}
                          referrerPolicy="no-referrer"
                          className="h-24 w-16 shrink-0 rounded-md object-cover"
                        />
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between font-mono-tabular text-[11px] font-semibold">
                          <span className={theme.accentTextClass}>{movie.lang}</span>
                          <span className="text-amber-300">{score}% Match</span>
                        </div>
                        <div className="mt-1 truncate font-display text-sm font-bold text-[#f4f1ea]">
                          {movie.title}
                        </div>
                        <div className="truncate text-[11px] text-[#9ca3b8]">
                          {movie.director} · {movie.year}
                        </div>
                      </div>
                    </div>

                    <div className="mt-2.5 border-t border-white/8 pt-2 text-[11px] text-emerald-300/90 truncate">
                      {sharedGenres.length > 0 ? sharedGenres.join(' · ') : 'Thematic match'}
                      {sharedStoryTerms.length > 0 ? ` · ${sharedStoryTerms.slice(0, 2).join(', ')}` : ''}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-white/12 bg-[#060608] px-4 py-6 text-center text-xs text-[#8b92a8]">
              No matches found for the current filters. Try switching to <strong className="text-[#f4f1ea]">All Languages (Mix)</strong> or unmuting genres.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
