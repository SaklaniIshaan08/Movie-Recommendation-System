import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowDownRight, GitCompareArrows, Play, User } from 'lucide-react';
import type { CatalogStats, Industry, Movie, UserVerdictTally, VerdictType } from '../types/movie';
import type { AuthUser } from './AuthModal';
import { POSTER_URLS } from '../data/posters';
import { computeDynamicPulse } from '../utils/pulse';
import { INDUSTRIES, INDUSTRY_THEMES } from '../utils/recommender';

interface HeroSpotlightProps {
  movies: Movie[];
  catalogStats: CatalogStats;
  activeIndustry: Industry | 'ALL';
  compareIds: number[];
  verdictTallies: Record<number, UserVerdictTally>;
  userPicks: Record<number, VerdictType>;
  user: AuthUser | null;
  onSelectIndustry: (lang: Industry | 'ALL') => void;
  onQuickSearch: (query: string) => void;
  onInspectMovie: (movie: Movie) => void;
  onToggleCompare: (movieId: number) => void;
  onOpenCompareLab: () => void;
  onOpenAuth: () => void;
}

interface SpotlightSlide {
  matchTitle: string;
  image: string;
  tagline: string;
  fallbackGradient: string;
}

const SPOTLIGHT_SLIDES: SpotlightSlide[] = [
  {
    matchTitle: 'Dhurandhar',
    image: '/src/assets/images/hero_espionage_noir_1795412470373.jpg',
    tagline: '2025 Espionage Event · Hindi Cinema',
    fallbackGradient: 'from-[#3d160b] via-[#120d0e] to-[#060608]',
  },
  {
    matchTitle: 'Jawan',
    image: '/src/assets/images/hero_crimson_action_1795412469929.jpg',
    tagline: 'High-Voltage Vigilante Spectacle · Hindi Cinema',
    fallbackGradient: 'from-[#4f101b] via-[#180b10] to-[#060608]',
  },
  {
    matchTitle: 'Sholay',
    image: '/src/assets/images/hero_deccan_western_1795412470504.jpg',
    tagline: '1975 70mm Landmark · Hindi Cinema',
    fallbackGradient: 'from-[#4d2c08] via-[#18100a] to-[#060608]',
  },
  {
    matchTitle: 'Bramayugam',
    image: '/src/assets/images/hero_monochrome_lantern_1795412470378.jpg',
    tagline: 'Silver-Gelatin Folk Horror · Malayalam Cinema',
    fallbackGradient: 'from-[#1a1f24] via-[#0d1014] to-[#060608]',
  },
];

const QUICK_PROMPTS = [
  { label: '12th Fail', query: '12th fail' },
  { label: 'Dhurandhar', query: 'durando' },
  { label: 'Dhurandhar: The Revenge', query: 'dhurandhar the revenge' },
  { label: 'Jawan', query: 'jawan' },
  { label: '1970s Hindi', query: 'Hindi 1970s' },
  { label: 'Malayalam < 2h', query: 'Malayalam under 2 hours' },
];

const MARQUEE_TITLES = [
  '12th Fail',
  'Dhurandhar',
  'Dhurandhar: The Revenge',
  'Jawan',
  'Sholay',
  'Bramayugam',
  'Maharaja',
  'Kantara',
  'Kalki 2898 AD',
  'Pyaasa',
  'Drishyam',
  '3 Idiots',
  'Vikram',
  'Deewaar',
];

export const HeroSpotlight: React.FC<HeroSpotlightProps> = ({
  movies,
  catalogStats,
  activeIndustry,
  compareIds,
  verdictTallies,
  userPicks,
  user,
  onSelectIndustry,
  onQuickSearch,
  onInspectMovie,
  onToggleCompare,
  onOpenCompareLab,
  onOpenAuth,
}) => {
  const [activeSlideIdx, setActiveSlideIdx] = useState(0);
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});

  const resolvedSlides = useMemo(() => {
    return SPOTLIGHT_SLIDES.map((slide) => {
      const movie =
        movies.find((m) => m.title.toLowerCase() === slide.matchTitle.toLowerCase()) ||
        movies[0];
      return { ...slide, movie };
    });
  }, [movies]);

  const marqueeMovies = useMemo(() => {
    return MARQUEE_TITLES.map((t) =>
      movies.find((m) => m.title.toLowerCase() === t.toLowerCase())
    ).filter((m): m is Movie => Boolean(m));
  }, [movies]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveSlideIdx((prev) => (prev + 1) % resolvedSlides.length);
    }, 6500);
    return () => window.clearInterval(timer);
  }, [resolvedSlides.length]);

  const current = resolvedSlides[activeSlideIdx];
  const activeMovie = current.movie;
  const activePoster = POSTER_URLS[activeMovie.id];
  const theme = INDUSTRY_THEMES[activeMovie.lang];
  const isCompared = compareIds.includes(activeMovie.id);
  const hindiPct =
    catalogStats.totalCount > 0
      ? Math.round((catalogStats.byLang.Hindi / catalogStats.totalCount) * 100)
      : 0;
  const activePulse = computeDynamicPulse(
    verdictTallies[activeMovie.id],
    userPicks[activeMovie.id] ?? null
  );

  return (
    <section className="relative overflow-hidden border-b border-white/[0.08] bg-[#060608]">
      {/* Opening Cinema Letterbox Entrance Accent */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
        className="h-[2px] w-full origin-left bg-gradient-to-r from-amber-400/70 via-amber-300/30 to-transparent"
      />

      {/* Main Split Hero */}
      <div className="mx-auto max-w-7xl px-4 pt-8 pb-8 sm:px-6 lg:pt-11 lg:pb-10">
        <div className="grid items-stretch gap-8 lg:grid-cols-12 lg:gap-10">
          {/* Left Typographic Editorial Stage */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-5"
          >
            <div>
              <p className="font-mono-tabular text-[11px] font-semibold tracking-[0.14em] text-amber-400">
                Indian Cinema Archive · {catalogStats.minYear} to {catalogStats.maxYear}
              </p>

              <h1 className="mt-3 text-balance font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-[#f4f1ea] sm:text-5xl">
                Five languages. One living cinema index.
              </h1>

              <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-[#a6acbe]">
                Explore <span className="font-mono-tabular font-semibold text-[#f4f1ea]">{catalogStats.totalCount}</span> curated titles led by{' '}
                <span className="font-mono-tabular font-semibold text-amber-300">
                  {catalogStats.byLang.Hindi} Hindi features ({hindiPct}%)
                </span>{' '}
                from {catalogStats.minYear} classics to {catalogStats.maxYear} releases, paired with Malayalam, Tamil, Telugu, and Kannada cinema.
              </p>

              {/* Primary & Secondary CTAs */}
              <div className="mt-6 flex flex-wrap items-center gap-2.5">
                <a
                  href="#catalog-grid"
                  className="inline-flex items-center gap-2 rounded-lg bg-amber-400 px-4 py-2.5 text-xs font-bold text-[#090a0d] whitespace-nowrap transition hover:bg-amber-300"
                >
                  <span>Browse Catalog</span>
                  <ArrowDownRight className="h-4 w-4" />
                </a>

                <button
                  type="button"
                  onClick={onOpenCompareLab}
                  className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-[#0e1017] px-4 py-2.5 text-xs font-semibold text-[#f4f1ea] whitespace-nowrap transition hover:border-amber-400/60 hover:text-amber-300 cursor-pointer"
                >
                  <GitCompareArrows className="h-4 w-4 text-amber-400" />
                  <span>Compare</span>
                </button>

                {!user && (
                  <button
                    type="button"
                    onClick={onOpenAuth}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/35 bg-amber-400/10 px-4 py-2.5 text-xs font-semibold text-amber-200 whitespace-nowrap transition hover:border-amber-400 hover:bg-amber-400/20 cursor-pointer"
                  >
                    <User className="h-3.5 w-3.5 text-amber-400" />
                    <span>Sign In</span>
                  </button>
                )}
              </div>
            </div>

            {/* Quick Spotlight Search Jump Strip */}
            <div className="mt-7 border-t border-white/[0.08] pt-4">
              <div className="text-[11px] font-medium text-[#7f859c]">Quick spotlight searches</div>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {QUICK_PROMPTS.map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => onQuickSearch(item.query)}
                    className="rounded-md border border-white/10 bg-[#0d0f15] px-2.5 py-1 text-xs font-medium text-[#d4d8e4] whitespace-nowrap transition hover:border-amber-400/50 hover:text-amber-300 cursor-pointer"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right Animated Widescreen Cinema Spotlight */}
          <motion.div
            initial={{ opacity: 0, scale: 0.985 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between gap-3 lg:col-span-7"
          >
            <div className="group relative flex-1 overflow-hidden rounded-xl border border-white/12 bg-[#0b0c11] min-h-[320px] sm:min-h-[370px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={current.matchTitle}
                  initial={{ opacity: 0, scale: 1.04 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute inset-0"
                >
                  {!imgErrors[current.image] ? (
                    <motion.img
                      src={current.image}
                      alt={`${activeMovie.title} theatrical spotlight frame`}
                      referrerPolicy="no-referrer"
                      onError={() =>
                        setImgErrors((prev) => ({ ...prev, [current.image]: true }))
                      }
                      initial={{ scale: 1 }}
                      animate={{ scale: 1.06 }}
                      transition={{ duration: 6.5, ease: 'linear' }}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div
                      className={`h-full w-full bg-gradient-to-br ${current.fallbackGradient}`}
                    />
                  )}
                </motion.div>
              </AnimatePresence>

              {/* Measured Contrast Scrim */}
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#060608] via-[#060608]/55 to-transparent" />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-[#060608]/88 via-[#060608]/25 to-transparent" />

              {/* Spotlight Content Overlay with Original Film Poster Inset */}
              <div className="relative z-10 flex h-full flex-col justify-between p-5 sm:p-6">
                <div className="flex items-center justify-between gap-3 text-xs">
                  <span className="font-mono-tabular font-medium text-[#e2dfd7]">
                    {current.tagline}
                  </span>
                  <span className="font-mono-tabular font-bold text-amber-300">
                    ★ {activeMovie.rating.toFixed(1)}
                  </span>
                </div>

                <div className="mt-auto flex items-end gap-4">
                  {activePoster && (
                    <button
                      type="button"
                      onClick={() => onInspectMovie(activeMovie)}
                      className="hidden sm:block shrink-0 overflow-hidden rounded-lg border border-white/20 shadow-2xl transition-transform duration-300 hover:scale-105 cursor-pointer"
                    >
                      <img
                        src={activePoster}
                        alt={`${activeMovie.title} official poster`}
                        referrerPolicy="no-referrer"
                        className="h-32 w-[86px] object-cover"
                      />
                    </button>
                  )}

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2 text-xs font-medium text-[#cbd0de]">
                      <span className={theme.accentTextClass}>{activeMovie.lang}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-tabular">{activeMovie.year}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-tabular">{activeMovie.runtime}m</span>
                      <span aria-hidden="true">·</span>
                      <span>{activeMovie.director}</span>
                    </div>

                    <h2 className="mt-1 font-display text-2xl font-extrabold tracking-tight text-[#f7f4ec] sm:text-3xl">
                      {activeMovie.title}
                    </h2>

                    <p className="mt-1 line-clamp-2 max-w-xl text-xs leading-relaxed text-[#cfd4e2] sm:text-sm">
                      {activeMovie.synopsis}
                    </p>

                    <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
                      {/* Audience Verdict Summary (shown when votes meet threshold) */}
                      <div className="min-w-[190px] flex-1 max-w-xs space-y-1">
                        {activePulse.hasSufficientData && activePulse.percentages ? (
                          <>
                            <div className="flex items-center justify-between font-mono-tabular text-[11px] text-[#cfd4e2]">
                              <span className="text-emerald-400 font-semibold">
                                {activePulse.percentages.perfection}% Masterpiece
                              </span>
                              <span className="text-[#9ea4b8]">
                                {activePulse.totalVotes} votes
                              </span>
                            </div>
                            <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-white/15">
                              <div className="h-full bg-emerald-400" style={{ width: `${activePulse.percentages.perfection}%` }} />
                              <div className="h-full bg-amber-400" style={{ width: `${activePulse.percentages.goforit}%` }} />
                              <div className="h-full bg-sky-400" style={{ width: `${activePulse.percentages.timepass}%` }} />
                              <div className="h-full bg-rose-500" style={{ width: `${activePulse.percentages.skip}%` }} />
                            </div>
                          </>
                        ) : (
                          <div className="text-[11px] text-[#b4bacb]">
                            Starring {activeMovie.cast.slice(0, 3).join(', ')}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onInspectMovie(activeMovie)}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-[#f4f1ea] px-3.5 py-2 text-xs font-bold text-[#090a0d] whitespace-nowrap transition hover:bg-amber-400 cursor-pointer"
                        >
                          <Play className="h-3.5 w-3.5 fill-current" />
                          <span>Watch Teaser &amp; Details</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onToggleCompare(activeMovie.id)}
                          className={`inline-flex items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                            isCompared
                              ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                              : 'border-white/20 bg-black/50 text-[#f4f1ea] hover:border-amber-400/70 hover:text-amber-300'
                          }`}
                        >
                          <GitCompareArrows className="h-3.5 w-3.5" />
                          <span>{isCompared ? 'Queued' : '+ Compare'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 4-Slot Interactive Reel Switcher */}
            <div className="grid grid-cols-4 gap-2">
              {resolvedSlides.map((slide, idx) => {
                const selected = idx === activeSlideIdx;
                return (
                  <button
                    key={slide.matchTitle}
                    type="button"
                    onClick={() => setActiveSlideIdx(idx)}
                    className={`rounded-lg border px-3 py-2 text-left transition cursor-pointer ${
                      selected
                        ? 'border-amber-400/70 bg-[#13151e]'
                        : 'border-white/[0.08] bg-[#0b0c11] opacity-70 hover:opacity-100 hover:border-white/20'
                    }`}
                  >
                    <div className="truncate font-display text-xs font-bold text-[#f4f1ea]">
                      {slide.movie.title}
                    </div>
                    <div className="mt-0.5 truncate font-mono-tabular text-[10px] text-[#9096ab]">
                      {slide.movie.lang} · {slide.movie.year}
                    </div>
                  </button>
                );
              })}
            </div>
          </motion.div>
        </div>

        {/* Full-Width 5-Industry Proportion Strip */}
        <div className="mt-8 grid grid-cols-2 gap-3 border-t border-white/[0.08] pt-6 sm:grid-cols-5">
          {INDUSTRIES.map((lang) => {
            const themeInfo = INDUSTRY_THEMES[lang];
            const isActive = activeIndustry === lang;
            const pct =
              catalogStats.totalCount > 0
                ? Math.round((catalogStats.byLang[lang] / catalogStats.totalCount) * 100)
                : 0;
            return (
              <button
                key={lang}
                type="button"
                onClick={() => onSelectIndustry(isActive ? 'ALL' : lang)}
                className={`group rounded-lg border px-3.5 py-2.5 text-left transition cursor-pointer ${
                  isActive
                    ? 'border-amber-400/70 bg-amber-400/[0.08]'
                    : 'border-white/[0.07] bg-[#0b0c11] hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className={`font-semibold ${themeInfo.accentTextClass}`}>{lang}</span>
                  <span className="font-mono-tabular text-[11px] text-[#7e859c]">{pct}%</span>
                </div>
                <div className="mt-1 font-mono-tabular text-xl font-bold text-[#f4f1ea]">
                  {catalogStats.byLang[lang]}
                </div>
                <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className={`h-full transition-all duration-300 ${themeInfo.barClass}`}
                    style={{ width: `${Math.max(10, pct)}%` }}
                  />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Smooth Kinetic Film-Strip Marquee with Mini Original Posters */}
      <div className="marquee-wrapper border-t border-white/[0.06] bg-[#090a0e] py-2.5 overflow-hidden">
        <div className="animate-cinema-marquee items-center gap-6 px-4">
          {[...marqueeMovies, ...marqueeMovies].map((m, i) => {
            const thumb = POSTER_URLS[m.id];
            return (
              <button
                key={`${m.id}-${i}`}
                type="button"
                onClick={() => onInspectMovie(m)}
                className="inline-flex items-center gap-2 text-xs text-[#9ea4b8] whitespace-nowrap transition hover:text-amber-300 cursor-pointer"
              >
                {thumb && (
                  <img
                    src={thumb}
                    alt=""
                    aria-hidden="true"
                    referrerPolicy="no-referrer"
                    className="h-6 w-4 rounded-sm object-cover opacity-90"
                  />
                )}
                <span className="font-semibold text-[#ece8df]">{m.title}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tabular text-[11px] text-[#7b8196]">
                  {m.lang} {m.year}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tabular text-[11px] text-amber-400">
                  ★ {m.rating.toFixed(1)}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
