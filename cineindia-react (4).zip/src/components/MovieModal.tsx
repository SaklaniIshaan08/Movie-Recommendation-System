import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Crown,
  Flame,
  Popcorn,
  ThumbsDown,
  GitCompareArrows,
  Plus,
  Check,
  Bookmark,
  Gem,
  Volume2,
  VolumeX,
  Play,
  Pause,
  MessageSquarePlus,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import type {
  AlgoWeights,
  MicroReview,
  Movie,
  UserVerdictTally,
  VerdictType,
} from '../types/movie';
import { POSTER_URLS } from '../data/posters';
import {
  getCuratedTrailerKey,
  isSafeBackdropUrl,
  isValidYouTubeKey,
} from '../data/trailers';
import { computeDynamicPulse } from '../utils/pulse';
import {
  getCrossIndustryTwins,
  getHiddenGemMetrics,
  INDUSTRY_THEMES,
} from '../utils/recommender';

interface MovieModalProps {
  movie: Movie | null;
  allMovies: Movie[];
  weights: AlgoWeights;
  verdictTally?: UserVerdictTally;
  userPick?: VerdictType | null;
  reviews: MicroReview[];
  defaultAuthor?: string;
  inDna: boolean;
  inCompare: boolean;
  inWatchlist: boolean;
  onClose: () => void;
  onSelectMovie: (movie: Movie) => void;
  onCastVerdict: (movieId: number, verdict: VerdictType) => void;
  onSubmitReview: (
    movieTitle: string,
    verdict: VerdictType,
    text: string,
    spoilerFree: boolean,
    author: string
  ) => void;
  onToggleDna: (movieId: number) => void;
  onToggleCompare: (movieId: number) => void;
  onToggleWatchlist: (movieId: number) => void;
}

const TIER_LABELS: Record<VerdictType, string> = {
  perfection: 'Masterpiece',
  goforit: 'Recommended',
  timepass: 'One-Time Watch',
  skip: 'Pass',
};

const TIER_ICONS: Record<VerdictType, React.ReactNode> = {
  perfection: <Crown className="h-3.5 w-3.5" />,
  goforit: <Flame className="h-3.5 w-3.5" />,
  timepass: <Popcorn className="h-3.5 w-3.5" />,
  skip: <ThumbsDown className="h-3.5 w-3.5" />,
};

const TIER_COLORS: Record<VerdictType, string> = {
  perfection: 'text-emerald-400',
  goforit: 'text-amber-400',
  timepass: 'text-sky-400',
  skip: 'text-rose-400',
};

export const MovieModal: React.FC<MovieModalProps> = ({
  movie,
  allMovies,
  weights,
  verdictTally,
  userPick = null,
  reviews,
  defaultAuthor = 'Cinephile',
  inDna,
  inCompare,
  inWatchlist,
  onClose,
  onSelectMovie,
  onCastVerdict,
  onSubmitReview,
  onToggleDna,
  onToggleCompare,
  onToggleWatchlist,
}) => {
  const [imgFailed, setImgFailed] = useState(false);
  const [youtubeKey, setYoutubeKey] = useState<string | null>(null);
  const [clipWindow, setClipWindow] = useState<{ startSec: number; endSec: number }>({
    startSec: 10,
    endSec: 52,
  });
  const [backdropUrl, setBackdropUrl] = useState<string | null>(null);
  const [trailerPlaying, setTrailerPlaying] = useState(true);
  const [trailerMuted, setTrailerMuted] = useState(true);

  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  const [composerOpen, setComposerOpen] = useState(false);
  const [reviewAuthor, setReviewAuthor] = useState(defaultAuthor);
  const [reviewVerdict, setReviewVerdict] = useState<VerdictType>('perfection');
  const [reviewText, setReviewText] = useState('');
  const [spoilerFree, setSpoilerFree] = useState(true);
  const [revealedReviews, setRevealedReviews] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setReviewAuthor(defaultAuthor);
  }, [defaultAuthor]);

  useEffect(() => {
    if (!movie) return;
    setImgFailed(false);
    setComposerOpen(false);
    setReviewText('');
    setTrailerPlaying(true);
    setTrailerMuted(true);

    const immediateKey = getCuratedTrailerKey(movie.title);
    setYoutubeKey(immediateKey);
    setClipWindow({ startSec: 10, endSec: 52 });
    setBackdropUrl(null);

    const controller = new AbortController();
    const params = new URLSearchParams({
      title: movie.title,
      year: String(movie.year),
      lang: movie.lang,
    });

    fetch(`/api/trailer?${params.toString()}`, { signal: controller.signal })
      .then((res) => (res.ok ? res.json() : null))
      .then(
        (
          data: {
            youtubeKey?: unknown;
            backdropUrl?: unknown;
            startSec?: unknown;
            endSec?: unknown;
          } | null
        ) => {
          if (!data) return;
          if (isValidYouTubeKey(data.youtubeKey)) {
            setYoutubeKey(data.youtubeKey);
          }
          if (
            typeof data.startSec === 'number' &&
            typeof data.endSec === 'number' &&
            data.endSec > data.startSec
          ) {
            setClipWindow({ startSec: data.startSec, endSec: data.endSec });
          }
          if (isSafeBackdropUrl(data.backdropUrl)) {
            setBackdropUrl(data.backdropUrl);
          }
        }
      )
      .catch(() => {
        // Fallback smoothly to animated backdrop if offline or aborted
      });

    return () => controller.abort();
  }, [movie?.id, movie?.title, movie?.year, movie?.lang]);

  // Keep glimpse looping seamlessly inside the 40s window before YouTube end-screen triggers
  useEffect(() => {
    if (!youtubeKey || !trailerPlaying) return;
    const durationMs = Math.max(18, clipWindow.endSec - clipWindow.startSec - 2) * 1000;
    const timer = window.setInterval(() => {
      iframeRef.current?.contentWindow?.postMessage(
        JSON.stringify({ event: 'command', func: 'seekTo', args: [clipWindow.startSec, true] }),
        'https://www.youtube-nocookie.com'
      );
      iframeRef.current?.contentWindow?.postMessage(
        JSON.stringify({ event: 'command', func: 'playVideo', args: [] }),
        'https://www.youtube-nocookie.com'
      );
    }, durationMs);
    return () => window.clearInterval(timer);
  }, [youtubeKey, trailerPlaying, clipWindow.startSec, clipWindow.endSec]);

  const sendPlayerCommand = (func: string, args: unknown[] = []) => {
    iframeRef.current?.contentWindow?.postMessage(
      JSON.stringify({ event: 'command', func, args }),
      'https://www.youtube-nocookie.com'
    );
  };

  const handleToggleMute = () => {
    const nextMuted = !trailerMuted;
    setTrailerMuted(nextMuted);
    sendPlayerCommand(nextMuted ? 'mute' : 'unMute');
  };

  const handleTogglePlay = () => {
    const nextPlaying = !trailerPlaying;
    setTrailerPlaying(nextPlaying);
    sendPlayerCommand(nextPlaying ? 'playVideo' : 'pauseVideo');
  };

  const movieReviews = useMemo(() => {
    if (!movie) return [];
    const target = movie.title.trim().toLowerCase();
    return reviews.filter((r) => r.movie.trim().toLowerCase() === target);
  }, [movie, reviews]);

  if (!movie) return null;

  const twins = getCrossIndustryTwins(movie, allMovies, weights, 3);
  const gemMetrics = getHiddenGemMetrics(movie, allMovies);
  const pulse = computeDynamicPulse(verdictTally, userPick);
  const theme = INDUSTRY_THEMES[movie.lang];
  const posterUrl = POSTER_URLS[movie.id];
  const ambientStill = backdropUrl || (posterUrl && !imgFailed ? posterUrl : null);

  const teaserEmbedUrl = youtubeKey
    ? `https://www.youtube-nocookie.com/embed/${youtubeKey}?autoplay=1&mute=1&start=${clipWindow.startSec}&end=${clipWindow.endSec}&controls=0&disablekb=1&fs=0&iv_load_policy=3&modestbranding=1&rel=0&playsinline=1&enablejsapi=1&loop=1&playlist=${youtubeKey}`
    : null;

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = reviewText.trim();
    if (!trimmed) return;
    onSubmitReview(
      movie.title,
      reviewVerdict,
      trimmed,
      spoilerFree,
      reviewAuthor.trim() || 'Cinephile'
    );
    setReviewText('');
    setComposerOpen(false);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${movie.title} details`}
      onClick={onClose}
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/85 p-3 sm:p-4 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.97, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="relative max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-white/12 bg-[#0b0c11] shadow-[0_32px_90px_rgba(0,0,0,0.92)]"
      >
        {/* Full-Width Unbranded Cinema Glimpse Stage Above the Poster */}
        <div
          className={`relative h-[220px] sm:h-[360px] w-full overflow-hidden bg-gradient-to-br ${theme.bannerGradient}`}
        >
          {/* Ambient Cinema Backdrop (shown immediately & when paused) */}
          {ambientStill && (
            <motion.img
              key={ambientStill}
              src={ambientStill}
              alt={`${movie.title} backdrop`}
              referrerPolicy="no-referrer"
              initial={{ scale: 1.03 }}
              animate={{ scale: 1.1 }}
              transition={{ duration: 14, repeat: Infinity, repeatType: 'reverse', ease: 'linear' }}
              className={`absolute inset-0 h-full w-full object-cover ${
                backdropUrl ? 'opacity-85' : 'opacity-45 blur-sm'
              }`}
            />
          )}

          {/* True Full-Width Overscanned Embed — Fills Edge-to-Edge & Crops Out Top Title / Prime / Netflix / YouTube Chrome */}
          {teaserEmbedUrl && (
            <iframe
              ref={iframeRef}
              key={youtubeKey}
              src={teaserEmbedUrl}
              title={`${movie.title} teaser`}
              tabIndex={-1}
              allow="autoplay; encrypted-media"
              className={`pointer-events-none absolute top-1/2 left-0 w-full aspect-video -translate-y-1/2 scale-[1.18] border-0 transition-opacity duration-500 ${
                trailerPlaying ? 'opacity-100' : 'opacity-0'
              }`}
            />
          )}

          {/* Subtle Bottom Edge Seam Fade Into Card Body */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#0b0c11] to-transparent" />

          {/* Clean Native Cinema Controls (No Platform Logos) */}
          <div className="absolute top-3.5 right-3.5 z-20 flex items-center gap-2">
            {youtubeKey && (
              <>
                <button
                  type="button"
                  onClick={handleToggleMute}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-black/75 px-2.5 py-1.5 text-[11px] font-semibold text-[#f4f1ea] backdrop-blur-md transition hover:border-amber-400/70 hover:text-amber-300 cursor-pointer"
                >
                  {trailerMuted ? (
                    <>
                      <VolumeX className="h-3.5 w-3.5" />
                      <span>Unmute</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="h-3.5 w-3.5 text-amber-400" />
                      <span>Sound On</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={handleTogglePlay}
                  aria-label={trailerPlaying ? 'Pause glimpse' : 'Play glimpse'}
                  className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-black/75 px-2.5 py-1.5 text-[11px] font-semibold text-[#f4f1ea] backdrop-blur-md transition hover:border-amber-400/70 hover:text-amber-300 cursor-pointer"
                >
                  {trailerPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  <span>{trailerPlaying ? 'Pause' : 'Play'}</span>
                </button>
              </>
            )}

            <button
              type="button"
              onClick={onClose}
              aria-label="Close modal"
              className="rounded-lg border border-white/15 bg-black/75 p-1.5 text-[#f4f1ea] backdrop-blur-md transition hover:border-amber-400/70 hover:text-amber-300 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Clean Below-Video Row: Official Poster + Title, Credits, Synopsis & Action Tabs */}
        <div className="border-b border-white/[0.08] bg-[#0b0c11] px-6 py-6">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
            {posterUrl && !imgFailed && (
              <div className="w-28 shrink-0 overflow-hidden rounded-xl border border-white/20 shadow-[0_18px_45px_rgba(0,0,0,0.8)] sm:w-36 aspect-[2/3]">
                <img
                  src={posterUrl}
                  alt={`${movie.title} poster`}
                  referrerPolicy="no-referrer"
                  onError={() => setImgFailed(true)}
                  className="h-full w-full object-cover"
                />
              </div>
            )}

            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 font-mono-tabular text-xs font-semibold text-[#e2dfd7]">
                <span className={theme.accentTextClass}>{movie.lang}</span>
                <span>·</span>
                <span>{movie.year}</span>
                <span>·</span>
                <span>{movie.runtime} mins</span>
                <span>·</span>
                <span className="text-amber-300">★ {movie.rating.toFixed(1)}</span>
                {gemMetrics.qualifies && (
                  <span className="inline-flex items-center gap-1 rounded-md border border-emerald-400/40 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                    <Gem className="h-3 w-3" />
                    Hidden Gem
                  </span>
                )}
              </div>

              <h2 className="mt-1.5 font-display text-2xl font-extrabold tracking-tight text-[#f7f4ec] sm:text-3xl">
                {movie.title}{' '}
                <span className="font-sans text-base font-normal text-[#c2c7d6] sm:text-lg">
                  ({movie.native})
                </span>
              </h2>

              <div className="mt-2 space-y-0.5 text-xs text-[#d3d7e4] sm:text-sm">
                <p>
                  Directed by <strong className="text-[#f7f4ec]">{movie.director}</strong>
                </p>
                <p>
                  Cast: <strong className="text-[#f7f4ec]">{movie.cast.join(', ')}</strong>
                </p>
              </div>

              <p className="mt-3 max-w-2xl text-sm leading-relaxed text-[#dfdcdc]">
                {movie.synopsis}
              </p>

              <div className="mt-4 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleWatchlist(movie.id)}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                    inWatchlist
                      ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                      : 'border-white/20 bg-[#131620] text-[#f4f1ea] hover:border-amber-400/70 hover:text-amber-300'
                  }`}
                >
                  <Bookmark className={`h-3.5 w-3.5 ${inWatchlist ? 'fill-current' : ''}`} />
                  <span>{inWatchlist ? 'In Watchlist' : 'Save Watchlist'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onToggleCompare(movie.id)}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                    inCompare
                      ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                      : 'border-white/20 bg-[#131620] text-[#f4f1ea] hover:border-amber-400/70 hover:text-amber-300'
                  }`}
                >
                  <GitCompareArrows className="h-3.5 w-3.5" />
                  <span>{inCompare ? 'Queued to Compare' : 'Compare Film'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onToggleDna(movie.id)}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                    inDna
                      ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                      : 'border-white/20 bg-[#131620] text-[#f4f1ea] hover:border-amber-400/70 hover:text-amber-300'
                  }`}
                >
                  {inDna ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
                  <span>{inDna ? 'In Test DNA' : 'Add to Test DNA'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setComposerOpen((v) => !v)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-[#131620] px-3 py-2 text-xs font-semibold text-[#f4f1ea] transition hover:border-amber-400/70 hover:text-amber-300 cursor-pointer"
                >
                  <MessageSquarePlus className="h-3.5 w-3.5 text-amber-400" />
                  <span>Write Review</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6 p-6">
          {/* Audience Verdict Voting */}
          <div className="rounded-xl border border-white/10 bg-[#07080b] p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-semibold">
              <span className="text-[#e8e5dd]">
                Audience Verdict{' '}
                {pulse.totalVotes > 0 && (
                  <span className="font-mono-tabular font-normal text-[#8b92a8]">
                    ({pulse.totalVotes} {pulse.totalVotes === 1 ? 'vote' : 'votes'})
                  </span>
                )}
              </span>

              {pulse.hasSufficientData && pulse.percentages ? (
                <span className="font-mono-tabular">
                  <span className="text-emerald-400">{pulse.percentages.perfection}% Masterpiece</span> ·{' '}
                  <span className="text-amber-400">{pulse.percentages.goforit}% Recommended</span> ·{' '}
                  <span className="text-sky-400">{pulse.percentages.timepass}% One-Time</span> ·{' '}
                  <span className="text-rose-400">{pulse.percentages.skip}% Pass</span>
                </span>
              ) : (
                <span className="text-[11px] font-normal text-[#8b92a8]">
                  {pulse.totalVotes === 0
                    ? 'Be the first to cast a verdict'
                    : 'Breakdown appears once 3 viewers vote'}
                </span>
              )}
            </div>

            {pulse.hasSufficientData && pulse.percentages && (
              <div className="mt-2.5 flex h-2 w-full overflow-hidden rounded-full bg-white/10">
                <div className="h-full bg-emerald-400 transition-all" style={{ width: `${pulse.percentages.perfection}%` }} />
                <div className="h-full bg-amber-400 transition-all" style={{ width: `${pulse.percentages.goforit}%` }} />
                <div className="h-full bg-sky-400 transition-all" style={{ width: `${pulse.percentages.timepass}%` }} />
                <div className="h-full bg-rose-500 transition-all" style={{ width: `${pulse.percentages.skip}%` }} />
              </div>
            )}

            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <button
                type="button"
                onClick={() => onCastVerdict(movie.id, 'perfection')}
                className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                  userPick === 'perfection'
                    ? 'border-emerald-400 bg-emerald-400 text-[#090a0d]'
                    : 'border-emerald-400/25 bg-emerald-400/10 text-emerald-300 hover:border-emerald-400 hover:bg-emerald-400/20'
                }`}
              >
                <Crown className="h-3.5 w-3.5" />
                <span>Masterpiece{pulse.tally.perfection > 0 ? ` (${pulse.tally.perfection})` : ''}</span>
              </button>
              <button
                type="button"
                onClick={() => onCastVerdict(movie.id, 'goforit')}
                className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                  userPick === 'goforit'
                    ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                    : 'border-amber-400/25 bg-amber-400/10 text-amber-300 hover:border-amber-400 hover:bg-amber-400/20'
                }`}
              >
                <Flame className="h-3.5 w-3.5" />
                <span>Recommended{pulse.tally.goforit > 0 ? ` (${pulse.tally.goforit})` : ''}</span>
              </button>
              <button
                type="button"
                onClick={() => onCastVerdict(movie.id, 'timepass')}
                className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                  userPick === 'timepass'
                    ? 'border-sky-400 bg-sky-400 text-[#090a0d]'
                    : 'border-sky-400/25 bg-sky-400/10 text-sky-300 hover:border-sky-400 hover:bg-sky-400/20'
                }`}
              >
                <Popcorn className="h-3.5 w-3.5" />
                <span>One-Time{pulse.tally.timepass > 0 ? ` (${pulse.tally.timepass})` : ''}</span>
              </button>
              <button
                type="button"
                onClick={() => onCastVerdict(movie.id, 'skip')}
                className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                  userPick === 'skip'
                    ? 'border-rose-400 bg-rose-400 text-[#090a0d]'
                    : 'border-rose-400/25 bg-rose-400/10 text-rose-300 hover:border-rose-400 hover:bg-rose-400/20'
                }`}
              >
                <ThumbsDown className="h-3.5 w-3.5" />
                <span>Pass{pulse.tally.skip > 0 ? ` (${pulse.tally.skip})` : ''}</span>
              </button>
            </div>
          </div>

          {/* Inline Film Reviews & Quick Composer */}
          <div className="rounded-xl border border-white/10 bg-[#07080b] p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-xs font-bold text-[#f4f1ea]">
                Viewer Reviews{' '}
                <span className="font-mono-tabular font-normal text-[#8b92a8]">
                  ({movieReviews.length})
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setComposerOpen((v) => !v)}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                <MessageSquarePlus className="h-3.5 w-3.5" />
                <span>{composerOpen ? 'Cancel' : 'Write a Review'}</span>
              </button>
            </div>

            {composerOpen && (
              <form
                onSubmit={handleReviewSubmit}
                className="mt-3 space-y-3 rounded-lg border border-white/10 bg-[#0b0c11] p-3.5"
              >
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-[11px] font-medium text-[#9ca3b8]">
                      Your Name
                    </label>
                    <input
                      type="text"
                      value={reviewAuthor}
                      onChange={(e) => setReviewAuthor(e.target.value)}
                      placeholder="Your name or handle"
                      className="w-full rounded-lg border border-white/12 bg-[#060608] px-3 py-1.5 text-xs text-[#f4f1ea] placeholder-[#676e85] focus:border-amber-400/70 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-medium text-[#9ca3b8]">
                      Your Verdict
                    </label>
                    <div className="grid grid-cols-4 gap-1">
                      {(Object.keys(TIER_LABELS) as VerdictType[]).map((v) => (
                        <button
                          key={v}
                          type="button"
                          onClick={() => setReviewVerdict(v)}
                          title={TIER_LABELS[v]}
                          className={`flex items-center justify-center rounded-lg border py-1.5 text-[11px] font-semibold transition cursor-pointer ${
                            reviewVerdict === v
                              ? 'border-amber-400 bg-amber-400/20 text-amber-300'
                              : 'border-white/10 bg-[#060608] text-[#9ca3b8] hover:text-[#f4f1ea]'
                          }`}
                        >
                          {TIER_ICONS[v]}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="mb-1 flex items-center justify-between text-[11px] text-[#9ca3b8]">
                    <span>Short Review</span>
                    <span className="font-mono-tabular">{reviewText.length}/280</span>
                  </div>
                  <textarea
                    maxLength={280}
                    rows={2}
                    required
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    placeholder={`Share what stood out in ${movie.title}...`}
                    className="w-full rounded-lg border border-white/12 bg-[#060608] p-2.5 text-xs text-[#f4f1ea] placeholder-[#676e85] focus:border-amber-400/70 focus:outline-none"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="flex items-center gap-2 text-xs text-[#b4bacb] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={spoilerFree}
                      onChange={(e) => setSpoilerFree(e.target.checked)}
                      className="accent-amber-400"
                    />
                    <span>Spoiler-free review</span>
                  </label>
                  <button
                    type="submit"
                    className="rounded-lg bg-amber-400 px-4 py-1.5 text-xs font-bold text-[#090a0d] hover:bg-amber-300 cursor-pointer"
                  >
                    Post Review
                  </button>
                </div>
              </form>
            )}

            {movieReviews.length > 0 ? (
              <div className="mt-3 space-y-2.5">
                {movieReviews.map((r) => {
                  const revealed = r.spoilerFree || revealedReviews[r.id];
                  return (
                    <div
                      key={r.id}
                      className="rounded-lg border border-white/[0.08] bg-[#0b0c11] p-3 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <strong className="text-[#f4f1ea]">@{r.user}</strong>
                          {r.spoilerFree ? (
                            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400">
                              <ShieldCheck className="h-3 w-3" />
                              Spoiler-Free
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] text-amber-400">
                              <AlertTriangle className="h-3 w-3" />
                              Spoiler
                            </span>
                          )}
                        </div>
                        <span className={`inline-flex items-center gap-1 font-semibold ${TIER_COLORS[r.verdict]}`}>
                          {TIER_ICONS[r.verdict]}
                          <span>{TIER_LABELS[r.verdict]}</span>
                        </span>
                      </div>
                      <p
                        onClick={() =>
                          !r.spoilerFree &&
                          setRevealedReviews((prev) => ({ ...prev, [r.id]: !prev[r.id] }))
                        }
                        className={`mt-1.5 leading-relaxed text-[#d3d7e4] ${
                          revealed ? '' : 'cursor-pointer blur-sm select-none'
                        }`}
                      >
                        {r.text}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              !composerOpen && (
                <p className="mt-2 text-xs text-[#8b92a8]">
                  No reviews posted yet for {movie.title}. Click <strong className="text-[#e6e3db]">Write a Review</strong> to add yours.
                </p>
              )
            )}
          </div>

          {/* Cross-Industry Discovery Twins */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <GitCompareArrows className="h-4 w-4 text-amber-400" />
                <h3 className="text-sm font-bold text-amber-300">
                  Cross-Industry Discovery Twins
                </h3>
              </div>
              <span className="text-xs text-[#8b92a8]">
                Kindred films across other Indian industries
              </span>
            </div>

            <div className="mt-3 grid gap-3 sm:grid-cols-3">
              {twins.map(({ movie: twin, score, sharedGenres, sharedStoryTerms, sameDirector }) => {
                const twinTheme = INDUSTRY_THEMES[twin.lang];
                const twinPoster = POSTER_URLS[twin.id];
                return (
                  <button
                    key={twin.id}
                    type="button"
                    onClick={() => onSelectMovie(twin)}
                    className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#07080b] p-3.5 text-left transition hover:border-amber-400/60 hover:bg-[#12151f] cursor-pointer"
                  >
                    <div className="flex items-start gap-3">
                      {twinPoster && (
                        <img
                          src={twinPoster}
                          alt=""
                          aria-hidden="true"
                          referrerPolicy="no-referrer"
                          className="h-20 w-14 shrink-0 rounded-md object-cover"
                        />
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between font-mono-tabular text-[11px] font-semibold">
                          <span className={twinTheme.accentTextClass}>{twin.lang}</span>
                          <span className="text-amber-300">{score}% Match</span>
                        </div>
                        <div className="mt-1 truncate font-display text-sm font-bold text-[#f4f1ea]">
                          {twin.title}
                        </div>
                        <div className="truncate text-[11px] text-[#9ca3b8]">
                          {twin.director} · {twin.year} · ★ {twin.rating.toFixed(1)}
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 border-t border-white/8 pt-2 text-[11px] text-[#9ea4b8] line-clamp-2">
                      {sharedGenres.length > 0 ? sharedGenres.join(' · ') : 'Kindred cinema'}
                      {sameDirector ? ` · Directed by ${twin.director}` : ''}
                      {sharedStoryTerms.length > 0 ? ` · Themes: ${sharedStoryTerms.slice(0, 3).join(', ')}` : ''}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
