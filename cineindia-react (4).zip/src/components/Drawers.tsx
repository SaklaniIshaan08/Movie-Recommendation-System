import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Dna,
  SlidersHorizontal,
  MessageSquareText,
  Crown,
  Flame,
  Popcorn,
  ThumbsDown,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import type { AlgoWeights, Industry, MicroReview, Movie, VerdictType } from '../types/movie';
import { INDUSTRIES } from '../utils/recommender';

interface TasteBlenderDrawerProps {
  open: boolean;
  seeds: Movie[];
  seedWeights: Record<number, number>;
  languageFilter: Industry | 'ALL';
  onClose: () => void;
  onRemoveSeed: (movieId: number) => void;
  onCycleSeedWeight: (movieId: number) => void;
  onChangeLanguageFilter: (lang: Industry | 'ALL') => void;
  onBlend: () => void;
  onClearAll: () => void;
}

export const TasteBlenderDrawer: React.FC<TasteBlenderDrawerProps> = ({
  open,
  seeds,
  seedWeights,
  languageFilter,
  onClose,
  onRemoveSeed,
  onCycleSeedWeight,
  onChangeLanguageFilter,
  onBlend,
  onClearAll,
}) => {
  if (!open) return null;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-40 flex justify-end bg-black/80 backdrop-blur-sm"
    >
      <motion.aside
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        aria-label="Test DNA Blender"
        className="flex h-full w-full max-w-md flex-col justify-between border-l border-white/12 bg-[#0b0c11] p-6 overflow-y-auto"
      >
        <div>
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="flex items-center gap-2">
              <Dna className="h-5 w-5 text-amber-400" />
              <h2 className="font-display text-xl font-bold text-[#f4f1ea]">
                Test DNA Blender
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Test DNA drawer"
              className="rounded-lg p-1.5 text-[#9aa2b8] hover:bg-white/10 hover:text-[#f4f1ea] cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <p className="mt-3 text-xs leading-relaxed text-[#9ca3b8]">
            Select <strong className="text-[#f4f1ea]">3 to 5 favorite films</strong> using{' '}
            <strong className="text-amber-300">+ Test DNA</strong> on any film card to unlock tailored picks across genres, languages, and eras.
          </p>

          <div className="mt-4">
            <div className="mb-2 text-xs font-semibold text-[#cfd4e3]">
              Recommendation Language
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => onChangeLanguageFilter('ALL')}
                className={`rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  languageFilter === 'ALL'
                    ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                    : 'border-white/12 bg-[#060608] text-[#b4bacb] hover:border-white/30 hover:text-[#f4f1ea]'
                }`}
              >
                All Languages (Mix)
              </button>
              {INDUSTRIES.map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => onChangeLanguageFilter(lang)}
                  className={`rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                    languageFilter === lang
                      ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                      : 'border-white/12 bg-[#060608] text-[#b4bacb] hover:border-white/30 hover:text-[#f4f1ea]'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between text-xs font-semibold text-[#cfd4e3]">
            <span>Selected Seeds</span>
            <span className="font-mono-tabular text-amber-400">{seeds.length} / 5</span>
          </div>

          <div className="mt-3 space-y-2">
            {seeds.length === 0 ? (
              <div className="rounded-xl border border-dashed border-white/15 bg-[#060608] p-4 text-xs text-[#838aa0]">
                No films selected yet. Hover over any film poster and click{' '}
                <strong className="text-[#e6e3db]">Test DNA</strong> on 3 to 5 films.
              </div>
            ) : (
              seeds.map((m) => {
                const w = seedWeights[m.id] ?? 1;
                return (
                  <div
                    key={m.id}
                    className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-[#060608] px-3.5 py-2.5 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="truncate font-semibold text-[#f4f1ea]">{m.title}</div>
                      <div className="truncate font-mono-tabular text-[11px] text-[#8b92a8]">
                        {m.lang} · {m.year} · {m.genres.slice(0, 2).join(', ')}
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onCycleSeedWeight(m.id)}
                        title="Adjust seed emphasis multiplier"
                        className="rounded border border-amber-400/40 bg-amber-400/10 px-2 py-0.5 font-mono-tabular text-[11px] font-bold text-amber-300 hover:bg-amber-400/20 cursor-pointer"
                      >
                        {w}×
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveSeed(m.id)}
                        aria-label={`Remove ${m.title}`}
                        className="rounded-md p-1 text-[#9aa2b8] hover:bg-white/10 hover:text-rose-300 cursor-pointer"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="mt-6 space-y-2 border-t border-white/10 pt-4">
          <button
            type="button"
            disabled={seeds.length < 3}
            onClick={onBlend}
            className="w-full rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-bold text-[#090a0d] transition hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-40 cursor-pointer"
          >
            {seeds.length < 3
              ? `Select ${3 - seeds.length} more film${3 - seeds.length > 1 ? 's' : ''} to build profile`
              : 'Show My Test DNA & Matches'}
          </button>
          {seeds.length > 0 && (
            <button
              type="button"
              onClick={onClearAll}
              className="w-full rounded-xl border border-white/12 bg-white/[0.03] px-4 py-2 text-xs font-semibold text-[#cbd0de] hover:border-white/25 cursor-pointer"
            >
              Clear Selection
            </button>
          )}
        </div>
      </motion.aside>
    </div>
  );
};

interface AlgoWeightsDrawerProps {
  open: boolean;
  weights: AlgoWeights;
  onClose: () => void;
  onChangeWeight: (key: keyof AlgoWeights, value: number) => void;
  onReset: () => void;
}

const WEIGHT_FIELDS: Array<{ key: keyof AlgoWeights; label: string; hint: string }> = [
  { key: 'genre', label: 'Genre Overlap', hint: 'Matches films that share similar genres' },
  { key: 'director', label: 'Director Match', hint: 'Boosts films directed by the same filmmaker' },
  { key: 'cast', label: 'Cast Overlap', hint: 'Matches recurring lead actors across industries' },
  { key: 'story', label: 'Story Similarity', hint: 'Matches shared plot themes and narrative style' },
  { key: 'cross', label: 'Cross-Industry Bonus', hint: 'Boosts discovery from other Indian film industries' },
  { key: 'era', label: 'Release Era', hint: 'Favors films released around the same decade' },
];

export const AlgoWeightsDrawer: React.FC<AlgoWeightsDrawerProps> = ({
  open,
  weights,
  onClose,
  onChangeWeight,
  onReset,
}) => {
  if (!open) return null;

  const total =
    Math.max(
      1,
      weights.genre + weights.director + weights.cast + weights.story + weights.cross + weights.era
    );

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-40 flex justify-end bg-black/80 backdrop-blur-sm"
    >
      <motion.aside
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        aria-label="Discovery Tuning Weights"
        className="flex h-full w-full max-w-md flex-col justify-between border-l border-white/12 bg-[#0b0c11] p-6 overflow-y-auto"
      >
        <div>
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-5 w-5 text-amber-400" />
              <h2 className="font-display text-xl font-bold text-[#f4f1ea]">
                Recommendation Tuning
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Tuning drawer"
              className="rounded-lg p-1.5 text-[#9aa2b8] hover:bg-white/10 hover:text-[#f4f1ea] cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <p className="mt-3 text-xs leading-relaxed text-[#9ca3b8]">
            Fine-tune what matters most when matching Discovery Twins and Test DNA recommendations.
          </p>

          <div className="mt-5 space-y-4">
            {WEIGHT_FIELDS.map((field) => {
              const normalizedPct = Math.round((weights[field.key] / total) * 100);
              return (
                <div key={field.key} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-[#e6e3db]">{field.label}</span>
                    <span className="font-mono-tabular text-amber-400">
                      {weights[field.key]} <span className="text-[#8b92a8]">({normalizedPct}%)</span>
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={60}
                    step={5}
                    value={weights[field.key]}
                    onChange={(e) => onChangeWeight(field.key, parseInt(e.target.value, 10))}
                    className="h-1.5 w-full cursor-pointer accent-amber-400"
                  />
                  <p className="text-[11px] text-[#7e859c]">{field.hint}</p>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-6 border-t border-white/10 pt-4">
          <button
            type="button"
            onClick={onReset}
            className="w-full rounded-xl border border-white/14 bg-white/[0.04] px-4 py-2.5 text-xs font-semibold text-[#e6e3db] hover:border-amber-400/60 hover:text-amber-300 cursor-pointer"
          >
            Reset Default Weights (25 / 20 / 10 / 25 / 10 / 10)
          </button>
        </div>
      </motion.aside>
    </div>
  );
};

interface MicroReviewsDrawerProps {
  open: boolean;
  movies: Movie[];
  reviews: MicroReview[];
  onClose: () => void;
  onSubmitReview: (movieTitle: string, verdict: VerdictType, text: string, spoilerFree: boolean, author: string) => void;
}

const VERDICT_META: Record<
  VerdictType,
  { label: string; colorClass: string; icon: React.ReactNode }
> = {
  perfection: { label: 'Masterpiece', colorClass: 'text-emerald-400', icon: <Crown className="h-3.5 w-3.5" /> },
  goforit: { label: 'Recommended', colorClass: 'text-amber-400', icon: <Flame className="h-3.5 w-3.5" /> },
  timepass: { label: 'One-Time Watch', colorClass: 'text-sky-400', icon: <Popcorn className="h-3.5 w-3.5" /> },
  skip: { label: 'Pass', colorClass: 'text-rose-400', icon: <ThumbsDown className="h-3.5 w-3.5" /> },
};

export const MicroReviewsDrawer: React.FC<MicroReviewsDrawerProps> = ({
  open,
  movies,
  reviews,
  onClose,
  onSubmitReview,
}) => {
  const [author, setAuthor] = useState('Cinephile');
  const [filmFilter, setFilmFilter] = useState('');
  const [selectedTitle, setSelectedTitle] = useState('Dhurandhar');
  const [verdict, setVerdict] = useState<VerdictType>('perfection');
  const [text, setText] = useState('');
  const [spoilerFree, setSpoilerFree] = useState(true);
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});

  const filteredMovies = useMemo(() => {
    const q = filmFilter.trim().toLowerCase();
    const base = q
      ? movies.filter(
          (m) =>
            m.title.toLowerCase().includes(q) ||
            m.hinglish.toLowerCase().includes(q) ||
            m.lang.toLowerCase().includes(q)
        )
      : movies;
    return base.slice(0, 60);
  }, [movies, filmFilter]);

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = text.trim();
    if (!cleaned) return;
    onSubmitReview(selectedTitle, verdict, cleaned, spoilerFree, author.trim() || 'Cinephile');
    setText('');
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-40 flex justify-end bg-black/80 backdrop-blur-sm"
    >
      <motion.aside
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        aria-label="Community Reviews"
        className="flex h-full w-full max-w-md flex-col border-l border-white/12 bg-[#0b0c11] p-6 overflow-y-auto"
      >
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2">
            <MessageSquareText className="h-5 w-5 text-amber-400" />
            <h2 className="font-display text-xl font-bold text-[#f4f1ea]">
              Community Reviews
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close reviews drawer"
            className="rounded-lg p-1.5 text-[#9aa2b8] hover:bg-white/10 hover:text-[#f4f1ea] cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3 border-b border-white/10 pb-5">
          <div>
            <label className="mb-1 block text-xs font-medium text-[#9ca3b8]">
              Your Handle
            </label>
            <input
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="e.g. Aarav_Cinema"
              className="w-full rounded-lg border border-white/12 bg-[#060608] px-3 py-1.5 text-xs text-[#f4f1ea] placeholder-[#676e85] focus:border-amber-400/70 focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-[#9ca3b8]">
              Find Film ({movies.length} available)
            </label>
            <input
              type="text"
              value={filmFilter}
              onChange={(e) => {
                setFilmFilter(e.target.value);
                const first = movies.find((m) =>
                  m.title.toLowerCase().includes(e.target.value.trim().toLowerCase())
                );
                if (first) setSelectedTitle(first.title);
              }}
              placeholder="Filter film list (e.g. 12th Fail, Dhurandhar, Sholay)..."
              className="mb-2 w-full rounded-lg border border-white/12 bg-[#060608] px-3 py-1.5 text-xs text-[#f4f1ea] placeholder-[#676e85] focus:border-amber-400/70 focus:outline-none"
            />
            <select
              value={selectedTitle}
              onChange={(e) => setSelectedTitle(e.target.value)}
              className="w-full rounded-lg border border-white/12 bg-[#060608] px-3 py-2 text-xs text-[#f4f1ea] focus:border-amber-400/70 focus:outline-none"
            >
              {filteredMovies.map((m) => (
                <option key={m.id} value={m.title}>
                  {m.title} ({m.lang} · {m.year})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            {(Object.keys(VERDICT_META) as VerdictType[]).map((v) => {
              const meta = VERDICT_META[v];
              const active = verdict === v;
              return (
                <button
                  key={v}
                  type="button"
                  onClick={() => setVerdict(v)}
                  className={`inline-flex items-center justify-center gap-1.5 rounded-lg border py-1.5 text-xs font-semibold transition cursor-pointer ${
                    active
                      ? 'border-amber-400 bg-amber-400/15 text-amber-300'
                      : 'border-white/10 bg-[#060608] text-[#9ca3b8] hover:text-[#f4f1ea]'
                  }`}
                >
                  {meta.icon}
                  <span>{meta.label}</span>
                </button>
              );
            })}
          </div>

          <div>
            <div className="mb-1 flex items-center justify-between text-xs text-[#9ca3b8]">
              <span>Your Review</span>
              <span className="font-mono-tabular">{text.length}/280</span>
            </div>
            <textarea
              maxLength={280}
              rows={3}
              required
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Write a crisp, spoiler-aware cinema note..."
              className="w-full rounded-xl border border-white/12 bg-[#060608] p-3 text-xs text-[#f4f1ea] placeholder-[#676e85] focus:border-amber-400/70 focus:outline-none"
            />
          </div>

          <label className="flex items-center gap-2 text-xs text-[#b4bacb] cursor-pointer">
            <input
              type="checkbox"
              checked={spoilerFree}
              onChange={(e) => setSpoilerFree(e.target.checked)}
              className="accent-amber-400"
            />
            <span>Mark as Spoiler-Free</span>
          </label>

          <button
            type="submit"
            className="w-full rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-bold text-[#090a0d] hover:bg-amber-300 cursor-pointer"
          >
            Publish Review
          </button>
        </form>

        <div className="mt-4 space-y-3">
          {reviews.map((r) => {
            const meta = VERDICT_META[r.verdict];
            const revealed = r.spoilerFree || revealedIds[r.id];
            return (
              <div
                key={r.id}
                className="rounded-xl border border-white/10 bg-[#060608] p-3.5 text-xs"
              >
                <div className="flex items-center justify-between gap-2">
                  <strong className="text-[#f4f1ea]">@{r.user}</strong>
                  <span className={`inline-flex items-center gap-1 font-semibold ${meta.colorClass}`}>
                    {meta.icon}
                    <span>{meta.label}</span>
                  </span>
                </div>
                <div className="mt-1 flex items-center gap-1.5 text-[11px] text-[#8b92a8]">
                  <span className="font-semibold text-[#cfd4e3]">{r.movie}</span>
                  <span>·</span>
                  {r.spoilerFree ? (
                    <span className="inline-flex items-center gap-1 text-emerald-400">
                      <ShieldCheck className="h-3 w-3" />
                      Spoiler-Free
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-amber-400">
                      <AlertTriangle className="h-3 w-3" />
                      Spoiler (click to reveal)
                    </span>
                  )}
                </div>
                <p
                  onClick={() =>
                    !r.spoilerFree &&
                    setRevealedIds((prev) => ({ ...prev, [r.id]: !prev[r.id] }))
                  }
                  className={`mt-2 leading-relaxed text-[#d3d7e4] transition ${
                    revealed ? '' : 'cursor-pointer blur-sm select-none'
                  }`}
                >
                  {r.text}
                </p>
              </div>
            );
          })}
        </div>
      </motion.aside>
    </div>
  );
};
