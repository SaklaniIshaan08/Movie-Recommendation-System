import React from 'react';
import { LogOut, User } from 'lucide-react';
import type { AuthUser } from './AuthModal';

interface NavbarProps {
  user: AuthUser | null;
  compareCount: number;
  blenderCount: number;
  reviewsCount: number;
  onResetCatalog: () => void;
  onOpenCompare: () => void;
  onOpenBlender: () => void;
  onOpenWeights: () => void;
  onOpenReviews: () => void;
  onOpenAuth: () => void;
  onSignOut: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  compareCount,
  blenderCount,
  reviewsCount,
  onResetCatalog,
  onOpenCompare,
  onOpenBlender,
  onOpenWeights,
  onOpenReviews,
  onOpenAuth,
  onSignOut,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.08] bg-[#060608]/92 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3.5 sm:px-6">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={onResetCatalog}
          className="group flex shrink-0 items-center gap-2.5 text-left whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-amber-400"
        >
          <svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            className="h-5 w-5 text-amber-400 transition-transform duration-200 group-hover:scale-105"
            fill="none"
          >
            <rect x="2.5" y="4.5" width="19" height="15" rx="2" stroke="currentColor" strokeWidth="1.7" />
            <path d="M6.5 4.5V19.5M17.5 4.5V19.5M2.5 9.5H6.5M2.5 14.5H6.5M17.5 9.5H21.5M17.5 14.5H21.5" stroke="currentColor" strokeWidth="1.4" />
          </svg>
          <span className="font-display text-lg font-extrabold tracking-tight text-[#f4f1ea] sm:text-xl">
            CineIndia
          </span>
        </button>

        {/* Zone 2: Clean Single-Line Typographic Nav Links */}
        <nav
          aria-label="Primary navigation"
          className="hidden lg:flex items-center gap-7 text-[13px] font-medium text-[#9ea4b8]"
        >
          <a
            href="#catalog-grid"
            className="relative py-1 whitespace-nowrap shrink-0 transition-colors hover:text-[#f4f1ea] after:absolute after:bottom-0 after:left-0 after:h-[1.5px] after:w-0 after:bg-amber-400 after:transition-all after:duration-200 hover:after:w-full"
          >
            Catalog
          </a>
          <button
            type="button"
            onClick={onOpenCompare}
            className="relative py-1 whitespace-nowrap shrink-0 transition-colors hover:text-[#f4f1ea] cursor-pointer after:absolute after:bottom-0 after:left-0 after:h-[1.5px] after:w-0 after:bg-amber-400 after:transition-all after:duration-200 hover:after:w-full"
          >
            Compare{compareCount > 0 ? ` (${compareCount})` : ''}
          </button>
          <button
            type="button"
            onClick={onOpenBlender}
            className="relative py-1 whitespace-nowrap shrink-0 transition-colors hover:text-[#f4f1ea] cursor-pointer after:absolute after:bottom-0 after:left-0 after:h-[1.5px] after:w-0 after:bg-amber-400 after:transition-all after:duration-200 hover:after:w-full"
          >
            Test DNA{blenderCount > 0 ? ` (${blenderCount})` : ''}
          </button>
          <button
            type="button"
            onClick={onOpenWeights}
            className="relative py-1 whitespace-nowrap shrink-0 transition-colors hover:text-[#f4f1ea] cursor-pointer after:absolute after:bottom-0 after:left-0 after:h-[1.5px] after:w-0 after:bg-amber-400 after:transition-all after:duration-200 hover:after:w-full"
          >
            Tuning
          </button>
          <button
            type="button"
            onClick={onOpenReviews}
            className="relative py-1 whitespace-nowrap shrink-0 transition-colors hover:text-[#f4f1ea] cursor-pointer after:absolute after:bottom-0 after:left-0 after:h-[1.5px] after:w-0 after:bg-amber-400 after:transition-all after:duration-200 hover:after:w-full"
          >
            Reviews ({reviewsCount})
          </button>
        </nav>

        {/* Zone 3: Sign In / Member Session */}
        <div className="flex shrink-0 items-center gap-3">

          {user ? (
            <div className="flex items-center gap-2 shrink-0">
              <span className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/35 bg-amber-400/10 px-3 py-1.5 text-xs font-semibold text-amber-200 whitespace-nowrap">
                <User className="h-3.5 w-3.5 text-amber-400" />
                <span className="max-w-[110px] truncate">{user.name}</span>
              </span>
              <button
                type="button"
                onClick={onSignOut}
                title="Sign out"
                aria-label="Sign out"
                className="rounded-lg border border-white/12 bg-[#0d0f15] p-1.5 text-[#9ea4b8] transition hover:border-rose-400/50 hover:text-rose-300 cursor-pointer"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenAuth}
              className="inline-flex items-center gap-2 rounded-lg bg-[#f4f1ea] px-4 py-2 text-xs font-bold text-[#090a0d] whitespace-nowrap shrink-0 transition-colors hover:bg-amber-400 cursor-pointer"
            >
              <User className="h-3.5 w-3.5" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>

      {/* Compact Mobile Sub-nav */}
      <div className="flex items-center justify-around border-t border-white/[0.06] px-2 py-1.5 text-[11px] font-medium text-[#9ea4b8] lg:hidden">
        <a href="#catalog-grid" className="px-2 py-1 hover:text-[#f4f1ea] whitespace-nowrap">
          Catalog
        </a>
        <button type="button" onClick={onOpenCompare} className="px-2 py-1 hover:text-[#f4f1ea] whitespace-nowrap cursor-pointer">
          Compare ({compareCount})
        </button>
        <button type="button" onClick={onOpenBlender} className="px-2 py-1 hover:text-[#f4f1ea] whitespace-nowrap cursor-pointer">
          Test DNA ({blenderCount})
        </button>
        <button type="button" onClick={onOpenReviews} className="px-2 py-1 hover:text-[#f4f1ea] whitespace-nowrap cursor-pointer">
          Reviews ({reviewsCount})
        </button>
      </div>
    </header>
  );
};
