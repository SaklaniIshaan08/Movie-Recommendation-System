export type Industry = 'Hindi' | 'Malayalam' | 'Tamil' | 'Telugu' | 'Kannada';

export type VerdictType = 'perfection' | 'goforit' | 'timepass' | 'skip';

export interface RecordCompleteness {
  hasPoster: boolean;
  hasSynopsis: boolean;
  hasCast: boolean;
  hasCredits: boolean;
  isComplete: boolean;
}

export interface SourceMetadata {
  catalogSource: string;
  referenceRatingSource: string;
  posterSource: 'IMDb Media CDN' | 'Typographic Poster Fallback';
}

export interface EditorialBaseline {
  perfection: number;
  goforit: number;
  timepass: number;
  skip: number;
}

export interface Movie {
  id: number;
  title: string;
  native: string;
  hinglish: string;
  lang: Industry;
  year: number;
  runtime: number;
  director: string;
  cast: string[];
  genres: string[];
  /** Curated reference score (0-10) from catalog metadata */
  rating: number;
  /** Reference archive popularity vote count (not live CineIndia votes) */
  votes: number;
  /** Static editorial baseline splits preserved only as fallback reference */
  perfection: number;
  goforit: number;
  timepass: number;
  skip: number;
  synopsis: string;
  completeness: RecordCompleteness;
  sourceMeta: SourceMetadata;
}

export interface CatalogStats {
  totalCount: number;
  byLang: Record<Industry, number>;
  minYear: number;
  maxYear: number;
  posterCount: number;
  completeCount: number;
  incompleteCount: number;
  allGenres: string[];
  meanRating: number;
}

export interface UserVerdictTally {
  perfection: number;
  goforit: number;
  timepass: number;
  skip: number;
}

export interface ComputedPulse {
  tally: UserVerdictTally;
  totalVotes: number;
  hasSufficientData: boolean;
  minVotesRequired: number;
  percentages: {
    perfection: number;
    goforit: number;
    timepass: number;
    skip: number;
  } | null;
  userPick: VerdictType | null;
}

export interface AlgoWeights {
  genre: number;
  director: number;
  cast: number;
  story: number;
  cross: number;
  era: number;
}

export interface ParsedQuery {
  lang: Industry | null;
  genres: string[];
  maxRuntime: number | null;
  minYear: number | null;
  maxYear: number | null;
  keywords: string[];
  mappedFromScript: string | null;
}

export interface SimilarityBreakdown {
  /** 0-100 metadata match (genres Jaccard, director, cast) */
  metadataPct: number;
  /** 0-100 TF-IDF cosine similarity over plot synopsis text */
  storyPct: number;
  /** 0 or 100 cross-industry bridge score */
  bridgePct: number;
  /** 0-100 temporal proximity score */
  eraPct: number;
  /** Weighted contribution points summing to compositeIndex */
  metadataContribution: number;
  storyContribution: number;
  bridgeContribution: number;
  eraContribution: number;
}

export interface SimilarityMatch {
  movie: Movie;
  /** Normalized 0-100 composite match index (NOT a probability of liking) */
  score: number;
  breakdown: SimilarityBreakdown;
  sharedGenres: string[];
  sharedCast: string[];
  sameDirector: boolean;
  sharedStoryTerms: string[];
  reasons: string[];
}

export interface HiddenGemMetrics {
  qualifies: boolean;
  bayesianRating: number;
  cohortMeanRating: number;
  cohortPriorVotes: number;
  cohortVisibilityPct: number;
  underDiscoveryPct: number;
  gemScore: number;
}

export interface TasteDnaSeedWeight {
  movieId: number;
  weight: number; // 0.5, 1, 1.5, 2
}

export interface TasteDnaProfile {
  seeds: Array<{
    movie: Movie;
    weight: number;
    contributionPct: number;
    topGenres: string[];
    topThemes: string[];
  }>;
  genreDistribution: Array<{ genre: string; pct: number; count: number }>;
  languageDistribution: Array<{ lang: Industry; pct: number; count: number }>;
  storyThemes: Array<{ term: string; score: number }>;
  eraProfile: {
    weightedMeanYear: number;
    minYear: number;
    maxYear: number;
    dominantEra: string;
  };
  runtimeProfile: {
    weightedAvgMinutes: number;
    pacingLabel: 'Tight (<120m)' | 'Standard (120–150m)' | 'Epic (>150m)';
  };
}

export interface MicroReview {
  id: string;
  user: string;
  movie: string;
  verdict: VerdictType;
  text: string;
  spoilerFree: boolean;
  createdAt: string;
}

export type SortOption = 'rating' | 'perfection' | 'gems' | 'newest' | 'oldest' | 'runtime';
export type EraOption = 'ALL' | '2020s' | '2010s' | '2000s' | '1990s' | '1980s' | 'Classic';
