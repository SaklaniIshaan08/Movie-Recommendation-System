import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Film } from 'lucide-react';
import { CATALOG_STATS, MOVIES as INITIAL_MOVIES } from './data/movies';
import type {
  AlgoWeights,
  EraOption,
  Industry,
  MicroReview,
  Movie,
  SortOption,
  UserVerdictTally,
  VerdictType,
} from './types/movie';
import { applyUserVote } from './utils/pulse';
import {
  buildHiddenGemMetricsMap,
  DEFAULT_ALGO_WEIGHTS,
  INDUSTRIES,
  parseNaturalLanguageQuery,
} from './utils/recommender';
import { buildTasteDnaProfile, recommendFromTasteDna } from './utils/tasteDna';
import { Navbar } from './components/Navbar';
import { HeroSpotlight } from './components/HeroSpotlight';
import { FilterBar } from './components/FilterBar';
import { TasteDnaShelf } from './components/TasteDnaShelf';
import { MovieCard } from './components/MovieCard';
import { MovieModal } from './components/MovieModal';
import { CompareDock, CompareLabModal } from './components/CompareLab';
import { AuthModal, type AuthUser } from './components/AuthModal';
import {
  AlgoWeightsDrawer,
  MicroReviewsDrawer,
  TasteBlenderDrawer,
} from './components/Drawers';

const PAGE_SIZE = 36;
const SEED_WEIGHT_STEPS = [0.5, 1, 1.5, 2];

const INITIAL_REVIEWS: MicroReview[] = [
  {
    id: 'r-1',
    user: 'Aarav_Mollywood',
    movie: 'Bramayugam',
    verdict: 'perfection',
    text: 'Black-and-white atmospheric dread at its finest. Mammootty turns a single mansion into a psychological labyrinth.',
    spoilerFree: true,
    createdAt: '2025-01-12',
  },
  {
    id: 'r-2',
    user: 'KavyaCinema',
    movie: 'Maharaja',
    verdict: 'perfection',
    text: 'Non-linear screenplay where every seemingly trivial detail clicks together in the final 15 minutes.',
    spoilerFree: true,
    createdAt: '2025-01-24',
  },
  {
    id: 'r-3',
    user: 'RohanCult',
    movie: 'Dhurandhar',
    verdict: 'goforit',
    text: 'Aditya Dhar stages espionage tension at relentless scale — brutal, tightly paced, and anchored by fierce ensemble turns.',
    spoilerFree: true,
    createdAt: '2025-12-08',
  },
];

export function App() {
  const [user, setUser] = useState<AuthUser | null>(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_session_v1');
      return saved ? (JSON.parse(saved) as AuthUser) : null;
    } catch {
      return null;
    }
  });
  const [authOpen, setAuthOpen] = useState(false);

  const movies = INITIAL_MOVIES;
  const gemMetricsMap = useMemo(() => buildHiddenGemMetricsMap(movies), [movies]);

  const [activeIndustry, setActiveIndustry] = useState<Industry | 'ALL'>('ALL');
  const [activeGenre, setActiveGenre] = useState<string>('ALL');
  const [era, setEra] = useState<EraOption>('ALL');
  const [sortBy, setSortBy] = useState<SortOption>('rating');
  const [hiddenGemsOnly, setHiddenGemsOnly] = useState(false);
  const [watchlistOnly, setWatchlistOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);

  const [weights, setWeights] = useState<AlgoWeights>(DEFAULT_ALGO_WEIGHTS);

  // Real persisted user verdict tallies & current user's vote per movie
  const [verdictTallies, setVerdictTallies] = useState<Record<number, UserVerdictTally>>(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_verdicts_v1');
      return saved ? (JSON.parse(saved) as Record<number, UserVerdictTally>) : {};
    } catch {
      return {};
    }
  });
  const [userPicks, setUserPicks] = useState<Record<number, VerdictType>>(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_user_picks_v1');
      return saved ? (JSON.parse(saved) as Record<number, VerdictType>) : {};
    } catch {
      return {};
    }
  });

  const [blenderIds, setBlenderIds] = useState<number[]>(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_dna_v1');
      return saved ? (JSON.parse(saved) as number[]) : [];
    } catch {
      return [];
    }
  });
  const [seedWeights, setSeedWeights] = useState<Record<number, number>>(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_dna_weights_v1');
      return saved ? (JSON.parse(saved) as Record<number, number>) : {};
    } catch {
      return {};
    }
  });
  const [excludedDnaGenres, setExcludedDnaGenres] = useState<string[]>([]);
  const [dnaCrossOnly, setDnaCrossOnly] = useState(false);
  const [dnaLanguageFilter, setDnaLanguageFilter] = useState<Industry | 'ALL'>('ALL');
  const [dnaShelfActive, setDnaShelfActive] = useState(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_dna_v1');
      return saved ? (JSON.parse(saved) as number[]).length >= 3 : false;
    } catch {
      return false;
    }
  });

  const [watchlistIds, setWatchlistIds] = useState<number[]>(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_watchlist_v1');
      return saved ? (JSON.parse(saved) as number[]) : [];
    } catch {
      return [];
    }
  });

  const [compareIds, setCompareIds] = useState<number[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);

  const [selectedMovieId, setSelectedMovieId] = useState<number | null>(null);
  const [activeDrawer, setActiveDrawer] = useState<
    'blender' | 'weights' | 'reviews' | null
  >(null);
  const [reviews, setReviews] = useState<MicroReview[]>(() => {
    try {
      const saved = window.localStorage.getItem('cineindia_reviews_v1');
      return saved ? (JSON.parse(saved) as MicroReview[]) : INITIAL_REVIEWS;
    } catch {
      return INITIAL_REVIEWS;
    }
  });
  const [toast, setToast] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const gridAnchorRef = useRef<HTMLDivElement | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
  };

  useEffect(() => {
    try {
      if (user) window.localStorage.setItem('cineindia_session_v1', JSON.stringify(user));
      else window.localStorage.removeItem('cineindia_session_v1');
    } catch {}
  }, [user]);

  useEffect(() => {
    try {
      window.localStorage.setItem('cineindia_verdicts_v1', JSON.stringify(verdictTallies));
    } catch {}
  }, [verdictTallies]);

  useEffect(() => {
    try {
      window.localStorage.setItem('cineindia_user_picks_v1', JSON.stringify(userPicks));
    } catch {}
  }, [userPicks]);

  useEffect(() => {
    try {
      window.localStorage.setItem('cineindia_watchlist_v1', JSON.stringify(watchlistIds));
    } catch {}
  }, [watchlistIds]);

  useEffect(() => {
    try {
      window.localStorage.setItem('cineindia_dna_v1', JSON.stringify(blenderIds));
    } catch {}
  }, [blenderIds]);

  useEffect(() => {
    try {
      window.localStorage.setItem('cineindia_dna_weights_v1', JSON.stringify(seedWeights));
    } catch {}
  }, [seedWeights]);

  useEffect(() => {
    try {
      window.localStorage.setItem('cineindia_reviews_v1', JSON.stringify(reviews));
    } catch {}
  }, [reviews]);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 2800);
    return () => window.clearTimeout(t);
  }, [toast]);

  // Global keyboard shortcuts (Alt+K search, Alt+O tuning, Escape close modals)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (authOpen) setAuthOpen(false);
        else if (compareOpen) setCompareOpen(false);
        else if (selectedMovieId !== null) setSelectedMovieId(null);
        else if (activeDrawer !== null) setActiveDrawer(null);
        return;
      }

      const tag = document.activeElement?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if (e.altKey) {
        const k = e.key.toLowerCase();
        if (k === 'k') {
          e.preventDefault();
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
        } else if (k === 'o') {
          e.preventDefault();
          setActiveDrawer((prev) => (prev === 'weights' ? null : 'weights'));
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [authOpen, compareOpen, selectedMovieId, activeDrawer]);

  const nlpParsed = useMemo(
    () => parseNaturalLanguageQuery(searchQuery),
    [searchQuery]
  );

  // Separate Filtered Stage vs Search Match Stage cleanly
  const filteredBeforeSearch = useMemo(() => {
    const watchlistSet = new Set(watchlistIds);
    return movies.filter((m) => {
      if (activeIndustry !== 'ALL' && m.lang !== activeIndustry) return false;
      if (activeGenre !== 'ALL' && !m.genres.includes(activeGenre)) return false;
      if (hiddenGemsOnly && !gemMetricsMap.get(m.id)?.qualifies) return false;
      if (watchlistOnly && !watchlistSet.has(m.id)) return false;

      if (era !== 'ALL') {
        if (era === '2020s' && m.year < 2020) return false;
        if (era === '2010s' && (m.year < 2010 || m.year > 2019)) return false;
        if (era === '2000s' && (m.year < 2000 || m.year > 2009)) return false;
        if (era === '1990s' && (m.year < 1990 || m.year > 1999)) return false;
        if (era === '1980s' && (m.year < 1980 || m.year > 1989)) return false;
        if (era === 'Classic' && m.year >= 1980) return false;
      }
      return true;
    });
  }, [movies, gemMetricsMap, activeIndustry, activeGenre, era, hiddenGemsOnly, watchlistOnly, watchlistIds]);

  const filteredMovies = useMemo(() => {
    const list = filteredBeforeSearch.filter((m) => {
      if (nlpParsed) {
        if (nlpParsed.lang && m.lang !== nlpParsed.lang) return false;
        if (nlpParsed.maxRuntime && m.runtime > nlpParsed.maxRuntime) return false;
        if (nlpParsed.minYear && m.year < nlpParsed.minYear) return false;
        if (nlpParsed.maxYear && m.year > nlpParsed.maxYear) return false;
        if (nlpParsed.keywords.length > 0) {
          const soup = `${m.title} ${m.native} ${m.hinglish} ${m.director} ${m.cast.join(
            ' '
          )} ${m.genres.join(' ')} ${m.synopsis} ${m.year}`.toLowerCase();
          if (!nlpParsed.keywords.every((kw) => soup.includes(kw))) return false;
        }
      }
      return true;
    });

    const sorted = [...list].sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating || b.votes - a.votes;
      if (sortBy === 'perfection') {
        const tA = verdictTallies[a.id];
        const tB = verdictTallies[b.id];
        const totA = tA ? tA.perfection + tA.goforit + tA.timepass + tA.skip : 0;
        const totB = tB ? tB.perfection + tB.goforit + tB.timepass + tB.skip : 0;
        const pA = totA >= 3 ? (tA.perfection / totA) * 100 : a.perfection;
        const pB = totB >= 3 ? (tB.perfection / totB) * 100 : b.perfection;
        return pB - pA || b.rating - a.rating;
      }
      if (sortBy === 'gems') {
        return (gemMetricsMap.get(b.id)?.gemScore ?? 0) - (gemMetricsMap.get(a.id)?.gemScore ?? 0);
      }
      if (sortBy === 'newest') return b.year - a.year || b.rating - a.rating;
      if (sortBy === 'oldest') return a.year - b.year || b.rating - a.rating;
      if (sortBy === 'runtime') return a.runtime - b.runtime;
      return 0;
    });

    return sorted;
  }, [filteredBeforeSearch, nlpParsed, sortBy, verdictTallies, gemMetricsMap]);

  const totalPages = Math.max(1, Math.ceil(filteredMovies.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);

  const paginatedMovies = useMemo(() => {
    const start = (safePage - 1) * PAGE_SIZE;
    return filteredMovies.slice(start, start + PAGE_SIZE);
  }, [filteredMovies, safePage]);

  const selectedMovie = useMemo(
    () => movies.find((m) => m.id === selectedMovieId) ?? null,
    [movies, selectedMovieId]
  );

  const compareMovies = useMemo(
    () =>
      compareIds
        .map((id) => movies.find((m) => m.id === id))
        .filter((m): m is Movie => Boolean(m)),
    [compareIds, movies]
  );

  const seedMovies = useMemo(
    () =>
      blenderIds
        .map((id) => movies.find((m) => m.id === id))
        .filter((m): m is Movie => Boolean(m)),
    [blenderIds, movies]
  );

  const dnaProfile = useMemo(() => {
    if (!dnaShelfActive || blenderIds.length < 3) return null;
    return buildTasteDnaProfile(blenderIds, seedWeights, movies);
  }, [dnaShelfActive, blenderIds, seedWeights, movies]);

  const dnaRecommendations = useMemo(() => {
    if (!dnaProfile) return [];
    return recommendFromTasteDna(dnaProfile, movies, weights, {
      crossIndustryOnly: dnaCrossOnly,
      languageFilter: dnaLanguageFilter,
      excludedGenres: excludedDnaGenres,
      limit: 4,
    });
  }, [dnaProfile, movies, weights, dnaCrossOnly, dnaLanguageFilter, excludedDnaGenres]);

  const handleToggleDna = (movieId: number) => {
    setBlenderIds((prev) => {
      if (prev.includes(movieId)) {
        const next = prev.filter((id) => id !== movieId);
        if (next.length < 3) setDnaShelfActive(false);
        return next;
      }
      if (prev.length >= 5) {
        showToast('Test DNA supports up to 5 seed films. Remove one to swap.');
        return prev;
      }
      const next = [...prev, movieId];
      if (next.length >= 3) setDnaShelfActive(true);
      return next;
    });
  };

  const handleCycleSeedWeight = (movieId: number) => {
    setSeedWeights((prev) => {
      const current = prev[movieId] ?? 1;
      const idx = SEED_WEIGHT_STEPS.indexOf(current);
      const nextVal = SEED_WEIGHT_STEPS[(idx + 1) % SEED_WEIGHT_STEPS.length];
      return { ...prev, [movieId]: nextVal };
    });
  };

  const handleToggleExcludeDnaGenre = (genre: string) => {
    setExcludedDnaGenres((prev) =>
      prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]
    );
  };

  const handleToggleCompare = (movieId: number) => {
    setCompareIds((prev) => {
      if (prev.includes(movieId)) {
        return prev.filter((id) => id !== movieId);
      }
      if (prev.length >= 3) {
        showToast('Comparison supports up to 3 films. Remove one to add another.');
        return prev;
      }
      const next = [...prev, movieId];
      if (next.length === 2) {
        showToast('2 films ready — click Compare Side-by-Side below.');
      }
      return next;
    });
  };

  const handleToggleWatchlist = (movieId: number) => {
    const movie = movies.find((m) => m.id === movieId);
    setWatchlistIds((prev) => {
      if (prev.includes(movieId)) {
        if (movie) showToast(`Removed ${movie.title} from Watchlist.`);
        return prev.filter((id) => id !== movieId);
      }
      if (movie) showToast(`Saved ${movie.title} to Watchlist.`);
      return [...prev, movieId];
    });
  };

  const handleCastVerdict = (movieId: number, verdict: VerdictType) => {
    const prevPick = userPicks[movieId] ?? null;
    const { tally, userPick } = applyUserVote(verdictTallies[movieId], prevPick, verdict);

    setVerdictTallies((prev) => ({ ...prev, [movieId]: tally }));
    setUserPicks((prev) => {
      const copy = { ...prev };
      if (userPick) copy[movieId] = userPick;
      else delete copy[movieId];
      return copy;
    });

    showToast(userPick ? 'Your verdict has been recorded.' : 'Your verdict was cleared.');
  };

  const handleResetAll = () => {
    setActiveIndustry('ALL');
    setActiveGenre('ALL');
    setEra('ALL');
    setHiddenGemsOnly(false);
    setWatchlistOnly(false);
    setSearchQuery('');
    setPage(1);
  };

  const changePage = (nextPage: number) => {
    setPage(nextPage);
    gridAnchorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen bg-[#060608] text-[#f4f1ea] film-grain-overlay">
      <Navbar
        user={user}
        compareCount={compareIds.length}
        blenderCount={blenderIds.length}
        reviewsCount={reviews.length}
        onResetCatalog={handleResetAll}
        onOpenCompare={() => setCompareOpen(true)}
        onOpenBlender={() => setActiveDrawer('blender')}
        onOpenWeights={() => setActiveDrawer('weights')}
        onOpenReviews={() => setActiveDrawer('reviews')}
        onOpenAuth={() => setAuthOpen(true)}
        onSignOut={() => {
          setUser(null);
          showToast('Signed out of CineIndia.');
        }}
      />

      <main>
        <HeroSpotlight
          movies={movies}
          catalogStats={CATALOG_STATS}
          activeIndustry={activeIndustry}
          compareIds={compareIds}
          verdictTallies={verdictTallies}
          userPicks={userPicks}
          user={user}
          onSelectIndustry={(lang) => {
            setActiveIndustry(lang);
            setPage(1);
            gridAnchorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }}
          onQuickSearch={(q) => {
            setSearchQuery(q);
            setActiveIndustry('ALL');
            setActiveGenre('ALL');
            setEra('ALL');
            setWatchlistOnly(false);
            setPage(1);
            gridAnchorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }}
          onInspectMovie={(m) => setSelectedMovieId(m.id)}
          onToggleCompare={handleToggleCompare}
          onOpenCompareLab={() => setCompareOpen(true)}
          onOpenAuth={() => setAuthOpen(true)}
        />

        <div ref={gridAnchorRef}>
          <FilterBar
            catalogStats={CATALOG_STATS}
            searchQuery={searchQuery}
            onSearchChange={(val) => {
              setSearchQuery(val);
              setPage(1);
            }}
            searchInputRef={searchInputRef}
            activeIndustry={activeIndustry}
            onIndustryChange={(lang) => {
              setActiveIndustry(lang);
              setPage(1);
            }}
            activeGenre={activeGenre}
            onGenreChange={(g) => {
              setActiveGenre(g);
              setPage(1);
            }}
            era={era}
            onEraChange={(e) => {
              setEra(e);
              setPage(1);
            }}
            sortBy={sortBy}
            onSortChange={(s) => {
              setSortBy(s);
              setPage(1);
            }}
            hiddenGemsOnly={hiddenGemsOnly}
            onToggleHiddenGems={() => {
              setHiddenGemsOnly((v) => !v);
              setPage(1);
            }}
            watchlistOnly={watchlistOnly}
            watchlistCount={watchlistIds.length}
            onToggleWatchlistOnly={() => {
              setWatchlistOnly((v) => !v);
              setPage(1);
            }}
            nlpParsed={nlpParsed}
            filteredBeforeSearchCount={filteredBeforeSearch.length}
            searchResultCount={filteredMovies.length}
            onResetAll={handleResetAll}
          />
        </div>

        <TasteDnaShelf
          profile={dnaProfile}
          recommendations={dnaRecommendations}
          excludedGenres={excludedDnaGenres}
          crossIndustryOnly={dnaCrossOnly}
          languageFilter={dnaLanguageFilter}
          onInspectMovie={(m) => setSelectedMovieId(m.id)}
          onToggleExcludeGenre={handleToggleExcludeDnaGenre}
          onCycleSeedWeight={handleCycleSeedWeight}
          onToggleCrossIndustry={() => {
            setDnaLanguageFilter('ALL');
            setDnaCrossOnly((v) => !v);
          }}
          onChangeLanguageFilter={(lang) => {
            setDnaLanguageFilter(lang);
            if (lang !== 'ALL') setDnaCrossOnly(false);
          }}
          onRegenerate={() => {
            setExcludedDnaGenres([]);
            setSeedWeights({});
            setDnaLanguageFilter('ALL');
            setDnaCrossOnly(false);
            showToast('Test DNA weights reset & profile regenerated.');
          }}
          onClear={() => {
            setBlenderIds([]);
            setSeedWeights({});
            setExcludedDnaGenres([]);
            setDnaLanguageFilter('ALL');
            setDnaCrossOnly(false);
            setDnaShelfActive(false);
          }}
        />

        {/* Real-Poster Film Grid */}
        <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
          {paginatedMovies.length === 0 ? (
            <div className="rounded-xl border border-dashed border-white/15 bg-[#0b0c11] px-6 py-16 text-center">
              <Film className="mx-auto h-9 w-9 text-[#656c82]" />
              <h3 className="mt-3 font-display text-xl font-bold text-[#f4f1ea]">
                No films matched your filter
              </h3>
              <p className="mt-1 text-sm text-[#8e95ab]">
                Try clearing your search tokens or switching between {INDUSTRIES.join(', ')}.
              </p>
              <button
                type="button"
                onClick={handleResetAll}
                className="mt-5 rounded-lg bg-amber-400 px-4 py-2 text-xs font-bold text-[#090a0d] hover:bg-amber-300 cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {paginatedMovies.map((movie, idx) => (
                  <MovieCard
                    key={movie.id}
                    movie={movie}
                    gemMetrics={gemMetricsMap.get(movie.id)!}
                    verdictTally={verdictTallies[movie.id]}
                    userPick={userPicks[movie.id] ?? null}
                    showGemMetrics={hiddenGemsOnly || sortBy === 'gems'}
                    index={idx}
                    inDna={blenderIds.includes(movie.id)}
                    inCompare={compareIds.includes(movie.id)}
                    inWatchlist={watchlistIds.includes(movie.id)}
                    onInspect={(m) => setSelectedMovieId(m.id)}
                    onToggleDna={handleToggleDna}
                    onToggleCompare={handleToggleCompare}
                    onToggleWatchlist={handleToggleWatchlist}
                  />
                ))}
              </div>

              {/* Pagination Bar */}
              {totalPages > 1 && (
                <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-white/[0.08] pt-6">
                  <p className="font-mono-tabular text-xs text-[#8b92a8]">
                    Page <strong className="text-[#f4f1ea]">{safePage}</strong> of{' '}
                    <strong className="text-[#f4f1ea]">{totalPages}</strong> · Showing{' '}
                    {(safePage - 1) * PAGE_SIZE + 1}–
                    {Math.min(safePage * PAGE_SIZE, filteredMovies.length)} of{' '}
                    {filteredMovies.length}
                  </p>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={safePage <= 1}
                      onClick={() => changePage(safePage - 1)}
                      className="inline-flex items-center gap-1 rounded-lg border border-white/12 bg-[#0d0f15] px-3 py-1.5 text-xs font-semibold text-[#d3d7e4] transition hover:border-amber-400/60 disabled:cursor-not-allowed disabled:opacity-40 cursor-pointer"
                    >
                      <ChevronLeft className="h-3.5 w-3.5" />
                      <span>Prev</span>
                    </button>

                    {Array.from({ length: totalPages }, (_, i) => i + 1)
                      .filter(
                        (p) =>
                          p === 1 ||
                          p === totalPages ||
                          Math.abs(p - safePage) <= 1
                      )
                      .map((p, idx, arr) => {
                        const prev = arr[idx - 1];
                        const gap = prev && p - prev > 1;
                        return (
                          <span key={p} className="inline-flex items-center gap-1.5">
                            {gap && (
                              <span className="px-1 font-mono-tabular text-xs text-[#697086]">
                                …
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => changePage(p)}
                              className={`min-w-[32px] rounded-lg border px-2 py-1.5 font-mono-tabular text-xs font-semibold transition cursor-pointer ${
                                p === safePage
                                  ? 'border-amber-400 bg-amber-400 text-[#090a0d]'
                                  : 'border-white/12 bg-[#0d0f15] text-[#b4bacb] hover:border-white/30 hover:text-[#f4f1ea]'
                              }`}
                            >
                              {p}
                            </button>
                          </span>
                        );
                      })}

                    <button
                      type="button"
                      disabled={safePage >= totalPages}
                      onClick={() => changePage(safePage + 1)}
                      className="inline-flex items-center gap-1 rounded-lg border border-white/12 bg-[#0d0f15] px-3 py-1.5 text-xs font-semibold text-[#d3d7e4] transition hover:border-amber-400/60 disabled:cursor-not-allowed disabled:opacity-40 cursor-pointer"
                    >
                      <span>Next</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </section>
      </main>

      <footer className="border-t border-white/[0.08] bg-[#050507] py-7">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-3 px-4 text-xs text-[#7e859c] sm:flex-row sm:items-center sm:px-6">
          <div>
            <strong className="text-[#f4f1ea]">CineIndia</strong> ·{' '}
            <span className="font-mono-tabular">
              {CATALOG_STATS.totalCount} titles ({CATALOG_STATS.minYear}–{CATALOG_STATS.maxYear})
            </span>{' '}
            · Hindi ({CATALOG_STATS.byLang.Hindi}), Malayalam ({CATALOG_STATS.byLang.Malayalam}), Tamil ({CATALOG_STATS.byLang.Tamil}), Telugu ({CATALOG_STATS.byLang.Telugu}) &amp; Kannada ({CATALOG_STATS.byLang.Kannada}).
          </div>
          <div className="text-[#9ea4b8]">
            Indian Cinema Discovery &amp; Companion Guide
          </div>
        </div>
      </footer>

      {/* Floating Compare Queue Bar */}
      <CompareDock
        movies={compareMovies}
        onRemove={handleToggleCompare}
        onOpenLab={() => setCompareOpen(true)}
        onClear={() => setCompareIds([])}
      />

      {/* Side-by-Side Visual Film Comparison Modal */}
      <CompareLabModal
        open={compareOpen}
        allMovies={movies}
        compareIds={compareIds}
        weights={weights}
        verdictTallies={verdictTallies}
        userPicks={userPicks}
        onClose={() => setCompareOpen(false)}
        onSetCompareIds={setCompareIds}
        onToggleCompare={handleToggleCompare}
        onInspectMovie={(m) => setSelectedMovieId(m.id)}
      />

      {/* Film Detail, Background Teaser, Reviews & Cross-Industry Twins Modal */}
      <MovieModal
        movie={selectedMovie}
        allMovies={movies}
        weights={weights}
        verdictTally={selectedMovie ? verdictTallies[selectedMovie.id] : undefined}
        userPick={selectedMovie ? userPicks[selectedMovie.id] ?? null : null}
        reviews={reviews}
        defaultAuthor={user ? user.name : 'Cinephile'}
        inDna={selectedMovie ? blenderIds.includes(selectedMovie.id) : false}
        inCompare={selectedMovie ? compareIds.includes(selectedMovie.id) : false}
        inWatchlist={selectedMovie ? watchlistIds.includes(selectedMovie.id) : false}
        onClose={() => setSelectedMovieId(null)}
        onSelectMovie={(m) => setSelectedMovieId(m.id)}
        onCastVerdict={handleCastVerdict}
        onSubmitReview={(movieTitle, verdict, text, spoilerFree, author) => {
          const finalAuthor = user ? user.name : author;
          setReviews((prev) => [
            {
              id: `r-${Date.now()}`,
              user: finalAuthor,
              movie: movieTitle,
              verdict,
              text,
              spoilerFree,
              createdAt: new Date().toISOString().slice(0, 10),
            },
            ...prev,
          ]);
          showToast(`Review saved for ${movieTitle}.`);
        }}
        onToggleDna={handleToggleDna}
        onToggleCompare={handleToggleCompare}
        onToggleWatchlist={handleToggleWatchlist}
      />

      {/* Member Sign In / Registration Modal */}
      <AuthModal
        open={authOpen}
        onClose={() => setAuthOpen(false)}
        onAuthenticated={(authUser) => {
          setUser(authUser);
          showToast(`Signed in as ${authUser.name}. Watchlist & Test DNA synced.`);
        }}
      />

      {/* Drawers */}
      <TasteBlenderDrawer
        open={activeDrawer === 'blender'}
        seeds={seedMovies}
        seedWeights={seedWeights}
        languageFilter={dnaLanguageFilter}
        onClose={() => setActiveDrawer(null)}
        onRemoveSeed={handleToggleDna}
        onCycleSeedWeight={handleCycleSeedWeight}
        onChangeLanguageFilter={(lang) => {
          setDnaLanguageFilter(lang);
          if (lang !== 'ALL') setDnaCrossOnly(false);
        }}
        onBlend={() => {
          setDnaShelfActive(true);
          setActiveDrawer(null);
          showToast('Test DNA profile updated.');
        }}
        onClearAll={() => {
          setBlenderIds([]);
          setSeedWeights({});
          setExcludedDnaGenres([]);
          setDnaLanguageFilter('ALL');
          setDnaCrossOnly(false);
          setDnaShelfActive(false);
        }}
      />

      <AlgoWeightsDrawer
        open={activeDrawer === 'weights'}
        weights={weights}
        onClose={() => setActiveDrawer(null)}
        onChangeWeight={(key, value) =>
          setWeights((prev) => ({ ...prev, [key]: value }))
        }
        onReset={() => {
          setWeights(DEFAULT_ALGO_WEIGHTS);
          showToast('Similarity weights reset to defaults.');
        }}
      />

      <MicroReviewsDrawer
        open={activeDrawer === 'reviews'}
        movies={movies}
        reviews={reviews}
        onClose={() => setActiveDrawer(null)}
        onSubmitReview={(movieTitle, verdict, text, spoilerFree, author) => {
          const finalAuthor = user ? user.name : author;
          setReviews((prev) => [
            {
              id: `r-${Date.now()}`,
              user: finalAuthor,
              movie: movieTitle,
              verdict,
              text,
              spoilerFree,
              createdAt: new Date().toISOString().slice(0, 10),
            },
            ...prev,
          ]);
          showToast(`Review saved for ${movieTitle}.`);
        }}
      />

      {/* Non-Blocking Accessible Toast */}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed right-5 bottom-20 z-50 rounded-xl border border-amber-400/50 bg-[#101219] px-4 py-2.5 text-xs font-semibold text-amber-200 shadow-2xl sm:bottom-5"
        >
          {toast}
        </div>
      )}
    </div>
  );
}

export default App;
