import { hydrateMovies, type RawMovieTuple } from './movieBuilder';
import { HINDI_CLASSICS } from './hindiClassics';
import { HINDI_MODERN_1 } from './hindiModern1';
import { HINDI_MODERN_2 } from './hindiModern2';
import { HINDI_MODERN_3 } from './hindiModern3';
import { HINDI_MODERN_4 } from './hindiModern4';
import { HINDI_EXTRA } from './hindiExtra';
import { MALAYALAM_MOVIES } from './malayalamMovies';
import { TAMIL_MOVIES } from './tamilMovies';
import { TELUGU_MOVIES } from './teluguMovies';
import { KANNADA_MOVIES } from './kannadaMovies';
import type { CatalogStats, Industry, Movie } from '../types/movie';

function deduplicateTuples(list: RawMovieTuple[]): RawMovieTuple[] {
  const seen = new Set<string>();
  const unique: RawMovieTuple[] = [];
  for (const item of list) {
    const key = `${item[0].trim().toLowerCase()}::${item[3]}::${item[4]}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(item);
    }
  }
  return unique;
}

function curateBalancedHindi(targetCount = 500): RawMovieTuple[] {
  const modern4 = deduplicateTuples(HINDI_MODERN_4);
  const classicsPool = deduplicateTuples([...HINDI_CLASSICS, ...HINDI_EXTRA.filter((m) => m[4] < 2000)]);
  const m1Pool = deduplicateTuples(HINDI_MODERN_1);
  const m2Pool = deduplicateTuples(HINDI_MODERN_2);
  const m3Pool = deduplicateTuples([...HINDI_MODERN_3, ...HINDI_EXTRA.filter((m) => m[4] >= 2000)]);

  const scoreTuple = (t: RawMovieTuple) => t[9] * 10 + Math.log10(t[10] + 10) * 6;
  const pickTop = (pool: RawMovieTuple[], count: number) =>
    [...pool].sort((a, b) => scoreTuple(b) - scoreTuple(a)).slice(0, count);

  const selected: RawMovieTuple[] = [
    ...modern4,
    ...pickTop(classicsPool, 145),
    ...pickTop(m1Pool, 85),
    ...pickTop(m2Pool, 90),
    ...pickTop(m3Pool, 85),
  ];

  const unique = deduplicateTuples(selected);
  if (unique.length < targetCount) {
    const fallbackPool = deduplicateTuples([
      ...classicsPool,
      ...m1Pool,
      ...m2Pool,
      ...m3Pool,
    ]).sort((a, b) => scoreTuple(b) - scoreTuple(a));
    const existingKeys = new Set(unique.map((u) => `${u[0].trim().toLowerCase()}::${u[3]}::${u[4]}`));
    for (const item of fallbackPool) {
      if (unique.length >= targetCount) break;
      const k = `${item[0].trim().toLowerCase()}::${item[3]}::${item[4]}`;
      if (!existingKeys.has(k)) {
        existingKeys.add(k);
        unique.push(item);
      }
    }
  }
  return unique.slice(0, targetCount);
}

const HINDI_CURATED = curateBalancedHindi(500);
const SOUTH_CURATED = deduplicateTuples([
  ...MALAYALAM_MOVIES,
  ...TAMIL_MOVIES,
  ...TELUGU_MOVIES,
  ...KANNADA_MOVIES,
]);

export const MOVIES: Movie[] = hydrateMovies([...HINDI_CURATED, ...SOUTH_CURATED]);

function computeCatalogStats(movies: Movie[]): CatalogStats {
  const byLang: Record<Industry, number> = {
    Hindi: 0,
    Malayalam: 0,
    Tamil: 0,
    Telugu: 0,
    Kannada: 0,
  };
  let minYear = Infinity;
  let maxYear = -Infinity;
  let posterCount = 0;
  let completeCount = 0;
  let ratingSum = 0;
  const genreSet = new Set<string>();

  for (const m of movies) {
    byLang[m.lang] += 1;
    if (m.year < minYear) minYear = m.year;
    if (m.year > maxYear) maxYear = m.year;
    if (m.completeness.hasPoster) posterCount += 1;
    if (m.completeness.isComplete) completeCount += 1;
    ratingSum += m.rating;
    for (const g of m.genres) genreSet.add(g);
  }

  return {
    totalCount: movies.length,
    byLang,
    minYear,
    maxYear,
    posterCount,
    completeCount,
    incompleteCount: movies.length - completeCount,
    allGenres: Array.from(genreSet).sort(),
    meanRating: Number((ratingSum / Math.max(1, movies.length)).toFixed(3)),
  };
}

export const CATALOG_STATS: CatalogStats = computeCatalogStats(MOVIES);
