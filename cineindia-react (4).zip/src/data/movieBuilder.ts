import type { Industry, Movie } from '../types/movie';
import { POSTER_URLS } from './posters';

export type RawMovieTuple = [
  title: string,
  native: string,
  hinglish: string,
  lang: Industry,
  year: number,
  runtime: number,
  director: string,
  cast: string[],
  genres: string[],
  rating: number,
  votes: number,
  perfection: number,
  goforit: number,
  timepass: number,
  skip: number,
  synopsis: string
];

export function hydrateMovies(tuples: RawMovieTuple[], startId = 1): Movie[] {
  return tuples.map((t, index) => {
    const id = startId + index;
    const hasPoster = Boolean(POSTER_URLS[id]);
    const hasSynopsis = Boolean(t[15] && t[15].trim().length >= 20);
    const hasCast = Array.isArray(t[7]) && t[7].length > 0;
    const hasCredits = Boolean(t[6] && t[6].trim().length > 0) && t[5] > 0;
    const isComplete = hasPoster && hasSynopsis && hasCast && hasCredits;

    return {
      id,
      title: t[0],
      native: t[1],
      hinglish: t[2],
      lang: t[3],
      year: t[4],
      runtime: t[5],
      director: t[6],
      cast: t[7],
      genres: t[8],
      rating: t[9],
      votes: t[10],
      perfection: t[11],
      goforit: t[12],
      timepass: t[13],
      skip: t[14],
      synopsis: t[15],
      completeness: {
        hasPoster,
        hasSynopsis,
        hasCast,
        hasCredits,
        isComplete,
      },
      sourceMeta: {
        catalogSource: 'CineIndia Curated Index',
        referenceRatingSource: 'Reference Archive Rating',
        posterSource: hasPoster ? 'IMDb Media CDN' : 'Typographic Poster Fallback',
      },
    };
  });
}
