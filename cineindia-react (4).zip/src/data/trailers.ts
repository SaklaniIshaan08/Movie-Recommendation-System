import type { Movie } from '../types/movie';

/**
 * Verified 11-character YouTube trailer/teaser keys for instant 0ms playback.
 * All entries are short official trailers/teasers (never full-length movies).
 * All remaining catalog titles resolve dynamically on demand via /api/trailer.
 */
export const CURATED_TRAILER_KEYS: Record<string, string> = {
  'gol maal': '1h4FG8ZI-tY',
  'khosla ka ghosla': 'ig1O2F8fv3M',
  'khosla ka ghosla!': 'ig1O2F8fv3M',
  '12th fail': 'KjbtuqENvVE',
  jawan: 'LifFf14Rq5I',
  dhurandhar: 'rZ_e-s6VvR4',
  'dhurandhar: the revenge': 'qfQ4-suh4Pk',
  bramayugam: '55pzldrBRJM',
  maharaja: 'UsW95hX8GTQ',
  tumbbad: '8A_jA_RxNV4',
  aavesham: 'tOM-nWPcR4U',
  rrr: 'NgBoMJy386M',
  chhichhore: 'tsxemFX0a7k',
  dangal: 'x_7YlGv9u1g',
  andhadhun: '2iVYI99VGaw',
  'gangs of wasseypur': '9ZpPQdrHfl8',
  'special 26': 'MqWAtOvHa4k',
  drishyam: 'eMASubc1y_k',
  'uri: the surgical strike': 'Cg8sbRFS3zU',
  'bhaag milkha bhaag': 'WbblCMem1ME',
  shahid: 'MVOIyZc2bPQ',
  'paan singh tomar': 'TT--NbNqiHE',
  'bajrangi bhaijaan': '4nwAra0mz_Q',
  pk: 'SOXWc32k4zA',
  'barfi!': 'fDpjzEKJjsM',
  barfi: 'fDpjzEKJjsM',
  neerja: 'aHza99Hc3lQ',
  'batla house': 'dG3K6jB3iW8',
  pink: 'AL2TShb6fFs',
  talvar: 'aQNMsw8Ljjc',
  'the tashkent files': 'OgWylHdfIdo',
  'section 375': 'UWjxS8EJ4Z8',
  awaara: 'heZKxrBjU_U',
  manichitrathazhu: 'D5SSyk_jaSE',
  nayakan: '1S6YkmYvgi8',
  mayabazar: 'E3h6mOmazAs',
};

const YOUTUBE_KEY_RE = /^[a-zA-Z0-9_-]{11}$/;

export function isValidYouTubeKey(value: unknown): value is string {
  return typeof value === 'string' && YOUTUBE_KEY_RE.test(value);
}

export function isSafeBackdropUrl(value: unknown): value is string {
  return (
    typeof value === 'string' &&
    value.startsWith('https://image.tmdb.org/t/p/')
  );
}

export function getCuratedTrailerKey(title: string): string | null {
  const key = CURATED_TRAILER_KEYS[title.trim().toLowerCase()];
  return isValidYouTubeKey(key) ? key : null;
}

export function getTrailerSearchUrl(movie: Movie): string {
  const query = `${movie.title} ${movie.year} ${movie.lang} official trailer`;
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
}
